import sys

def solve():
    data = sys.stdin.buffer.read().split()
    it = iter(data)
    n = int(next(it))
    m = int(next(it))
    h = n // m
    stacks = []
    for _ in range(m):
        stack = [int(next(it)) for _ in range(h)]
        stacks.append(stack)
    
    # Position map: box value -> (stack_index, position_in_stack)
    pos_map = {}
    for i, stack in enumerate(stacks):
        for j, v in enumerate(stack):
            pos_map[v] = (i, j)
    
    operations = []
    total_energy = 0
    
    for target_val in range(1, n + 1):
        src_idx, src_pos = pos_map[target_val]
        
        if src_pos < len(stacks[src_idx]) - 1:
            # There are boxes above target_val in the source stack
            # Move all boxes above to a destination stack
            above_boxes = stacks[src_idx][src_pos + 1:]
            k = len(above_boxes)
            
            # Choose best destination: minimize future cost
            # Heuristic: choose stack where these boxes will be useful soonest
            # Try each possible destination and estimate cost
            best_dest = None
            best_score = float('inf')
            
            for dest_idx in range(m):
                if dest_idx == src_idx:
                    continue
                
                # Score: prefer shorter stacks, and consider how many of these
                # boxes will need to be moved again from this destination
                current_len = len(stacks[dest_idx])
                
                # Count how many of the above boxes have values that will be
                # needed before they reach the top of the destination stack
                # This is complex; use simpler heuristic
                # Prefer stacks with fewer boxes
                score = current_len
                
                # Also consider: if moving to a stack where some of these boxes
                # are already 'in order' (smaller values below), that's better
                # For simplicity, just use stack length as primary criterion
                
                if score < best_score or (best_dest is None):
                    best_score = score
                    best_dest = dest_idx
            
            # If multiple stacks have same length, pick one where the bottom-most
            # box of the moved group has the smallest value (more likely to be
            # accessed soon)
            candidates = [j for j in range(m) if j != src_idx and len(stacks[j]) == best_score]
            if len(candidates) > 1:
                def est_cost(j):
                    # Estimate: how many of the above boxes will need to be
                    # moved again if placed on stack j
                    # Boxes with smaller values than the minimum of stack j's
                    # existing boxes might cause issues
                    min_existing = min(stacks[j]) if stacks[j] else n + 1
                    count = sum(1 for b in above_boxes if b < min_existing)
                    return count
                best_dest = min(candidates, key=est_cost)
            
            energy = k + 1
            total_energy += energy
            operations.append((above_boxes[0], best_dest + 1))
            
            # Update state
            stacks[best_dest].extend(above_boxes)
            del stacks[src_idx][src_pos + 1:]
            
            # Update pos_map for moved boxes
            for idx, box in enumerate(above_boxes):
                new_pos = len(stacks[best_dest]) - len(above_boxes) + idx
                pos_map[box] = (best_dest, new_pos)
            
            # Update pos_map for remaining boxes in source stack (positions unchanged)
            # They stay at same positions, so no update needed
        
        # Now carry out target_val
        operations.append((target_val, 0))
        
        # Remove target_val from its stack
        src_idx, src_pos = pos_map[target_val]
        assert stacks[src_idx][-1] == target_val, f"Expected {target_val} at top of stack {src_idx}, got {stacks[src_idx]}"
        del stacks[src_idx][-1]
        del pos_map[target_val]
    
    # Output operations
    out_lines = []
    for v, i in operations:
        out_lines.append(f"{v} {i}")
    sys.stdout.write("\n".join(out_lines) + "\n")

solve()
