import sys

def solve():
    data = sys.stdin.buffer.read().split()
    it = iter(data)
    n = int(next(it))
    m = int(next(it))
    h = n // m
    stacks = []
    for _ in range(m):
        stack = [int(next(it)) for _ in range(h)]
        stacks.append(stack)
    
    # Position map: box value -> (stack_index, position_in_stack)
    pos_map = {}
    for i, stack in enumerate(stacks):
        for j, v in enumerate(stack):
            pos_map[v] = (i, j)
    
    operations = []
    total_energy = 0
    
    for target_val in range(1, n + 1):
        src_idx, src_pos = pos_map[target_val]
        
        if src_pos < len(stacks[src_idx]) - 1:
            above_boxes = stacks[src_idx][src_pos + 1:]
            k = len(above_boxes)
            
            # Choose best destination: minimize future cost
            best_dest = None
            best_score = float('inf')
            
            for dest_idx in range(m):
                if dest_idx == src_idx:
                    continue
                
                current_len = len(stacks[dest_idx])
                
                # Count how many of the above boxes will need to be moved again
                # A box needs to be moved again if its value is less than some box
                # already in the destination stack that is below it after placement
                # Since we're placing on top, all existing boxes are below.
                # So a box b in above_boxes needs to be moved again if there exists
                # a box c in stacks[dest_idx] with c > b (c is below b after placement,
                # but c has larger value so c must be removed before b can be taken out)
                
                # Actually, let's think more carefully:
                # After moving above_boxes to dest, the dest stack becomes:
                # [existing boxes..., above_boxes...]
                # For a box b in above_boxes at position p in the new stack,
                # it can only be taken out when all boxes below it have been taken out.
                # Boxes below include all existing boxes and earlier boxes in above_boxes.
                # If any box below b has a value greater than b, then that box must be
                # taken out before b, which means b must be moved again (since b is on top).
                
                # Simpler heuristic: count boxes in above_boxes that are smaller than
                # the minimum of existing boxes in dest. These definitely need re-moving.
                min_existing = min(stacks[dest_idx]) if stacks[dest_idx] else n + 1
                conflict_count = sum(1 for b in above_boxes if b < min_existing)
                
                # Score: prefer shorter stacks and fewer conflicts
                score = current_len * 10 + conflict_count
                
                if score < best_score:
                    best_score = score
                    best_dest = dest_idx
            
            energy = k + 1
            total_energy += energy
            operations.append((above_boxes[0], best_dest + 1))
            
            # Update state
            base_pos = len(stacks[best_dest])
            stacks[best_dest].extend(above_boxes)
            del stacks[src_idx][src_pos + 1:]
            
            for idx, box in enumerate(above_boxes):
                pos_map[box] = (best_dest, base_pos + idx)
        
        # Carry out target_val
        operations.append((target_val, 0))
        src_idx, src_pos = pos_map[target_val]
        assert stacks[src_idx][-1] == target_val
        del stacks[src_idx][-1]
        del pos_map[target_val]
    
    out_lines = []
    for v, i in operations:
        out_lines.append(f"{v} {i}")
    sys.stdout.write("\n".join(out_lines) + "\n")

solve()