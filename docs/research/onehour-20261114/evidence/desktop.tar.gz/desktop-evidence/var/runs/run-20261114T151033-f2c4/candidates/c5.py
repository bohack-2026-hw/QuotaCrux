import sys

def solve():
    data = sys.stdin.buffer.read().split()
    it = iter(data)
    n = int(next(it))
    m = int(next(it))
    h = n // m
    stacks = []
    for _ in range(m):
        stack = [int(next(it)) for _ in range(h)]
        stacks.append(stack)
    
    # Position map: box value -> (stack_index, position_in_stack)
    pos_map = {}
    for i, stack in enumerate(stacks):
        for j, v in enumerate(stack):
            pos_map[v] = (i, j)
    
    operations = []
    total_energy = 0
    
    def simulate_future(stacks_state, next_val, steps=5):
        """Simulate the next `steps` moves and return the total energy cost."""
        cost = 0
        remaining = set(range(next_val, n + 1))
        if not remaining:
            return 0
        min_remaining = min(remaining)
        
        for _ in range(steps):
            if min_remaining not in pos_map_temp:
                break
            src_idx, src_pos = pos_map_temp[min_remaining]
            stack_len = len(stacks_state[src_idx])
            if src_pos < stack_len - 1:
                k = stack_len - src_pos - 1
                cost += k + 1
            # Simulate: remove boxes above and take out min_remaining
            del stacks_state[src_idx][src_pos + 1:]
            del stacks_state[src_idx][src_pos]
            remaining.discard(min_remaining)
            if remaining:
                min_remaining = min(remaining)
            else:
                break
        return cost
    
    for target_val in range(1, n + 1):
        src_idx, src_pos = pos_map[target_val]
        
        if src_pos < len(stacks[src_idx]) - 1:
            above_boxes = stacks[src_idx][src_pos + 1:]
            k = len(above_boxes)
            
            # For each candidate dest, estimate future cost
            best_dest = None
            best_total = float('inf')
            
            for dest_idx in range(m):
                if dest_idx == src_idx:
                    continue
                
                # Create a temporary copy to simulate
                temp_stacks = [s[:] for s in stacks]
                temp_stacks[dest_idx].extend(above_boxes[:])
                del temp_stacks[src_idx][src_pos + 1:]
                
                # Update temp pos_map for estimation
                global pos_map_temp
                pos_map_temp = {}
                for i, stack in enumerate(temp_stacks):
                    for j, v in enumerate(stack):
                        pos_map_temp[v] = (i, j)
                
                future_cost = simulate_future(temp_stacks, target_val + 1, steps=3)
                total_cost = k + 1 + future_cost
                
                if total_cost < best_total:
                    best_total = total_cost
                    best_dest = dest_idx
            
            energy = k + 1
            total_energy += energy
            operations.append((above_boxes[0], best_dest + 1))
            
            # Update actual state
            base_pos = len(stacks[best_dest])
            stacks[best_dest].extend(above_boxes)
            del stacks[src_idx][src_pos + 1:]
            
            for idx, box in enumerate(above_boxes):
                pos_map[box] = (best_dest, base_pos + idx)
        
        # Carry out target_val
        operations.append((target_val, 0))
        src_idx, src_pos = pos_map[target_val]
        assert stacks[src_idx][-1] == target_val
        del stacks[src_idx][-1]
        del pos_map[target_val]
    
    out_lines = []
    for v, i in operations:
        out_lines.append(f"{v} {i}")
    sys.stdout.write("\n".join(out_lines) + "\n")

solve()