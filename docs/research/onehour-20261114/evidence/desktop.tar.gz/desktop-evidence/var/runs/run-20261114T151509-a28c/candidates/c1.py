import sys,time,random

def main():
    data=list(map(int,sys.stdin.buffer.read().split()))
    if not data:return
    n,m=data[:2]; h=n//m
    initial=[data[2+i*h:2+(i+1)*h] for i in range(m)]
    rng=random.Random(726013)
    deadline=time.perf_counter()+1.65
    best=10**9; bestops=[]; trial=0
    while trial<1600 and (trial<12 or time.perf_counter()<deadline):
        stacks=[s[:] for s in initial]
        where=[0]*(n+1)
        for i,s in enumerate(stacks):
            for v in s:where[v]=i
        mins=[min(s) if s else n+1 for s in stacks]
        ops=[]; cost=0
        if trial==0: merge=0.; noise=0.; hp=0.
        elif trial==1: merge=1.; noise=0.; hp=0.
        else:
            merge=rng.choice([0.,0.,0.,.03,.07,.12,.2,.35,.6])
            noise=rng.choice([0.,3.,8.,15.,25.,40.])
            hp=rng.choice([0.,0.,.1,.3,.7])
        for value in range(1,n+1):
            src=where[value]; s=stacks[src]; pos=s.index(value)
            while len(s)>pos+1:
                end=len(s); cut=end-1
                while cut>pos+1:
                    if s[cut-1]>s[cut] or rng.random()<merge:cut-=1
                    else:break
                block=s[cut:]; mx=max(block)
                dest=-1; val=1e30
                for j in range(m):
                    if j==src:continue
                    mn=mins[j]
                    score=(mn-mx if mn>mx else 2*n-mn)+hp*len(stacks[j])
                    if noise:score+=rng.random()*noise
                    if score<val:val=score;dest=j
                ops.append((block[0],dest+1));cost+=len(block)+1
                stacks[dest].extend(block)
                if min(block)<mins[dest]:mins[dest]=min(block)
                for x in block:where[x]=dest
                del s[cut:]
            ops.append((value,0));s.pop()
            mins[src]=min(s) if s else n+1
            if cost>=best:break
        if cost<best and len(ops)>=n:
            best=cost;bestops=ops
        trial+=1
    sys.stdout.write('\n'.join(str(v)+' '+str(i) for v,i in bestops))

if __name__=='__main__':main()
