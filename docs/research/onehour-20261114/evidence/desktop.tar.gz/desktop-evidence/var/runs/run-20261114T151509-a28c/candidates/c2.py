import sys,time,random,math

def main():
    data=list(map(int,sys.stdin.buffer.read().split()))
    if not data:return
    n,m=data[:2];h=n//m
    initial=[data[2+i*h:2+(i+1)*h] for i in range(m)]
    rng=random.Random(726013)
    start=time.perf_counter();deadline=start+1.75
    def solve(policy=None,change=-1,mode=0,noise=0.,merge=0.):
        stacks=[s[:] for s in initial]
        where=[0]*(n+1)
        for j,s in enumerate(stacks):
            for x in s:where[x]=j
        mins=[min(s) if s else n+1 for s in stacks]
        ops=[];trace={};keys=[];cost=0
        for v in range(1,n+1):
            src=where[v];s=stacks[src];p=s.index(v)
            while len(s)>p+1:
                key=v*(n+1)+s[-1]
                old=policy.get(key) if policy is not None else None
                cut=-1;dest=-1
                if old is not None:
                    b,d=old
                    if b in s:
                        q=s.index(b)
                        if q>p:cut=q;dest=d
                if cut<0:
                    cut=len(s)-1
                    while cut>p+1 and (s[cut-1]>s[cut] or (merge and rng.random()<merge)):cut-=1
                if key==change:
                    if mode:
                        if rng.random()<.75:
                            choices=[p+1]
                            choices.extend(q for q in range(p+2,len(s)) if s[q-1]<s[q])
                            cut=rng.choice(choices)
                        else:cut=rng.randrange(p+1,len(s))
                        dest=-1
                    else:dest=-1
                block=s[cut:];mx=max(block)
                if dest<0 or dest==src:
                    scores=[]
                    for j in range(m):
                        if j==src:continue
                        mn=mins[j]
                        val=mn-mx if mn>mx else 2*n-mn
                        if noise:val+=rng.random()*noise
                        scores.append((val,j))
                    scores.sort()
                    if key==change and not mode:
                        choices=[j for _,j in scores if old is None or j!=old[1]]
                        r=rng.random()
                        rank=0 if r<.48 else (1 if r<.75 else (2 if r<.90 else rng.randrange(len(choices))))
                        dest=choices[min(rank,len(choices)-1)]
                    else:dest=scores[0][1]
                trace[key]=(block[0],dest);keys.append(key)
                ops.append((block[0],dest+1));cost+=len(block)+1
                stacks[dest].extend(block)
                bm=min(block)
                if bm<mins[dest]:mins[dest]=bm
                for x in block:where[x]=dest
                del s[cut:]
            ops.append((v,0));s.pop();mins[src]=min(s) if s else n+1
        return cost,ops,trace,keys
    current=solve();best=current
    for z in range(16):
        q=solve(noise=rng.choice([0.,5.,12.,25.,40.]),merge=rng.choice([0.,0.,.03,.1,.25]))
        if q[0]<best[0]:best=q
    current=best;iteration=0;stale=0
    while time.perf_counter()<deadline:
        key=rng.choice(current[3])
        mode=1 if rng.random()<.32 else 0
        q=solve(current[2],key,mode)
        elapsed=(time.perf_counter()-start)/1.75
        temperature=4.5*(1-elapsed)+.35
        delta=q[0]-current[0]
        if delta<=0 or rng.random()<math.exp(-delta/temperature):current=q
        if q[0]<best[0]:best=q;stale=0
        else:stale+=1
        if stale>100:current=best;stale=0
        iteration+=1
    sys.stdout.write('\n'.join(str(v)+' '+str(d) for v,d in best[1]))

if __name__=='__main__':main()
