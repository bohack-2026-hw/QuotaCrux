import sys,time,random,math

def main():
    data=list(map(int,sys.stdin.buffer.read().split()))
    if not data:return
    n,m=data[:2];h=n//m
    initial=[data[2+i*h:2+(i+1)*h] for i in range(m)]
    rng=random.Random(726013)
    start=time.perf_counter(); deadline=start+1.78
    stride=8
    def solve(old=None,idx=-1,mode=0,noise=0.,merge=0.):
        if old is None:
            stacks=[s[:] for s in initial]; cost=0;ops=[];keys=[];trace={};check=[];v0=1
            policy={}
        else:
            policy=old[2];target=old[3][idx]
            vtarget=target//(n+1)
            ci=(vtarget-1)//stride
            v0,state,cost,oi,ki=old[4][ci]
            stacks=[s[:] for s in state]
            ops=old[1][:oi];keys=old[3][:ki]
            trace={k:policy[k] for k in keys}
            check=old[4][:ci]
        where=[0]*(n+1)
        mins=[n+1]*m
        for j,s in enumerate(stacks):
            if s:mins[j]=min(s)
            for x in s:where[x]=j
        for v in range(v0,n+1):
            if (v-1)%stride==0:
                check.append((v,[s[:] for s in stacks],cost,len(ops),len(keys)))
            src=where[v];s=stacks[src];p=s.index(v)
            while len(s)>p+1:
                key=v*(n+1)+s[-1]
                prev=policy.get(key)
                cut=-1;dest=-1
                if prev is not None:
                    b,d=prev
                    if b in s:
                        q=s.index(b)
                        if q>p:cut=q;dest=d
                if cut<0:
                    cut=len(s)-1
                    while cut>p+1 and (s[cut-1]>s[cut] or (merge and rng.random()<merge)):cut-=1
                changed=old is not None and key==target
                if changed:
                    if mode:
                        choices=[p+1]
                        choices.extend(q for q in range(p+2,len(s)) if s[q-1]<s[q])
                        choices=[q for q in choices if q!=cut]
                        if choices and rng.random()<.92:cut=rng.choice(choices)
                        elif len(s)>p+2:
                            cut=rng.randrange(p+1,len(s))
                        dest=-1
                    else:dest=-1
                block=s[cut:]
                if dest<0 or dest==src:
                    mx=max(block);scores=[]
                    for j in range(m):
                        if j==src:continue
                        mn=mins[j]
                        val=mn-mx if mn>mx else 2*n-mn
                        if noise:val+=rng.random()*noise
                        scores.append((val,j))
                    scores.sort()
                    if changed and not mode:
                        choices=[j for _,j in scores if prev is None or j!=prev[1]]
                        r=rng.random()
                        rank=0 if r<.55 else (1 if r<.82 else (2 if r<.94 else rng.randrange(len(choices))))
                        dest=choices[min(rank,len(choices)-1)]
                    else:dest=scores[0][1]
                trace[key]=(block[0],dest);keys.append(key)
                ops.append((block[0],dest+1));cost+=len(block)+1
                stacks[dest].extend(block)
                bm=min(block)
                if bm<mins[dest]:mins[dest]=bm
                for x in block:where[x]=dest
                del s[cut:]
            ops.append((v,0));s.pop();mins[src]=min(s) if s else n+1
        return cost,ops,trace,keys,check
    best=solve()
    for z in range(10):
        q=solve(noise=rng.choice([0.,5.,12.,25.,40.]),merge=rng.choice([0.,0.,.03,.1,.25]))
        if q[0]<best[0]:best=q
    current=best;stale=0;iteration=0
    while time.perf_counter()<deadline:
        idx=rng.randrange(len(current[3]))
        q=solve(current,idx,1 if rng.random()<.32 else 0)
        elapsed=(time.perf_counter()-start)/1.78
        temp=3.0*(1-elapsed)+.2
        delta=q[0]-current[0]
        if delta<=0 or rng.random()<math.exp(-delta/max(.15,temp)):current=q
        if q[0]<best[0]:best=q;stale=0
        else:stale+=1
        if stale>160:current=best;stale=0
        iteration+=1
    sys.stdout.write('\n'.join(str(v)+' '+str(d) for v,d in best[1]))
if __name__=='__main__':main()
