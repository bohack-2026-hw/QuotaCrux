import sys,time,random,math,bisect

def main():
    data=list(map(int,sys.stdin.buffer.read().split()))
    if not data:return
    n,m=data[:2];h=n//m
    initial=[data[2+i*h:2+(i+1)*h] for i in range(m)]
    rng=random.Random(726013)
    start=time.perf_counter();deadline=start+1.78;stride=5
    def snapshots(sol,oldchecks=None,ci=0):
        if oldchecks is None:
            stacks=[s[:] for s in initial];cost=0;oi0=0;ki=0
            check=[(1,[s[:] for s in stacks],0,0,0)]
        else:
            v0,state,cost,oi0,ki=oldchecks[ci]
            stacks=[s[:] for s in state];check=oldchecks[:ci+1]
        where=[0]*(n+1)
        for j,s in enumerate(stacks):
            for x in s:where[x]=j
        for oi in range(oi0,len(sol[1])):
            v,d=sol[1][oi];src=where[v];s=stacks[src]
            if d:
                p=s.index(v);b=s[p:];del s[p:];d-=1
                stacks[d].extend(b)
                for x in b:where[x]=d
                cost+=len(b)+1;ki+=1
            else:
                s.pop()
                if v%stride==0 and v<n:check.append((v+1,[s[:] for s in stacks],cost,oi+1,ki))
        return check
    def materialize(q):
        return (q[0],q[1],dict(zip(q[3],q[4])),q[3],q[4],q[5],q[6])
    def solve(old=None,idx=-1,mode=0,noise=0.,merge=0.):
        if old is None:
            stacks=[s[:] for s in initial];cost=0;ops=[];keys=[];decs=[];weights=[];v0=1;policy={};target=-1;ci=0
        else:
            policy=old[2];target=old[3][idx];vt=target//(n+1);ci=(vt-1)//stride
            v0,state,cost,oi,ki=checks[ci]
            stacks=[s[:] for s in state];ops=old[1][:oi];keys=old[3][:ki];decs=old[4][:ki];weights=old[5][:ki]
        where=[0]*(n+1);mins=[n+1]*m
        for j,s in enumerate(stacks):
            if s:mins[j]=min(s)
            for x in s:where[x]=j
        reset=False
        for v in range(v0,n+1):
            src=where[v];s=stacks[src];p=s.index(v)
            while len(s)>p+1:
                key=v*(n+1)+s[-1];prev=None if reset else policy.get(key)
                cut=-1;dest=-1
                if prev is not None:
                    b,d=prev
                    if b in s:
                        q=s.index(b)
                        if q>p:cut=q;dest=d
                if cut<0:
                    cut=len(s)-1
                    while cut>p+1 and (s[cut-1]>s[cut] or (merge and rng.random()<merge)):cut-=1
                changed=key==target
                if changed:
                    if mode in (1,2):
                        choices=[q for q in range(p+1,len(s)) if q!=cut and (q==p+1 or s[q-1]<s[q])]
                        if choices and rng.random()<.9:cut=rng.choice(choices)
                        elif len(s)>p+2:cut=rng.randrange(p+1,len(s))
                    if mode==3:reset=True
                    dest=-1
                block=s[cut:]
                if dest<0 or dest==src:
                    mx=max(block);scores=[]
                    for j in range(m):
                        if j==src:continue
                        mn=mins[j];val=mn-mx if mn>mx else 2*n-mn
                        if noise:val+=rng.random()*noise
                        scores.append((val,j))
                    scores.sort()
                    if changed and mode in (0,2,3):
                        choices=[j for _,j in scores if prev is None or j!=prev[1]]
                        r=rng.random();rank=0 if r<.60 else (1 if r<.85 else (2 if r<.96 else rng.randrange(len(choices))))
                        dest=choices[min(rank,len(choices)-1)]
                    else:dest=scores[0][1]
                decs.append((block[0],dest));keys.append(key)
                weights.append((weights[-1] if weights else 0)+len(block)+1)
                ops.append((block[0],dest+1));cost+=len(block)+1
                stacks[dest].extend(block);bm=min(block)
                if bm<mins[dest]:mins[dest]=bm
                for x in block:where[x]=dest
                del s[cut:]
            ops.append((v,0));s.pop();mins[src]=min(s) if s else n+1
        return cost,ops,None,keys,decs,weights,ci
    best=materialize(solve())
    for z in range(8):
        q=solve(noise=rng.choice([0.,5.,12.,25.,40.]),merge=rng.choice([0.,0.,.03,.1,.25]))
        if q[0]<best[0]:best=materialize(q)
    current=best;checks=snapshots(current);stale=0
    while time.perf_counter()<deadline:
        if not current[3]:break
        if rng.random()<.5:idx=rng.randrange(len(current[3]))
        else:idx=bisect.bisect_right(current[5],rng.randrange(current[5][-1]))
        r=rng.random();mode=0 if r<.60 else (1 if r<.88 else (2 if r<.96 else 3))
        q=solve(current,idx,mode)
        elapsed=(time.perf_counter()-start)/1.78;temp=2.5*(1-elapsed)+.15
        delta=q[0]-current[0]
        if delta<=0 or rng.random()<math.exp(-delta/max(.15,temp)):
            current=materialize(q);checks=snapshots(current,checks,q[6])
        if q[0]<best[0]:best=current;stale=0
        else:stale+=1
        if stale>230:
            current=best;checks=snapshots(current);stale=0
    sys.stdout.write('\n'.join(str(v)+' '+str(d) for v,d in best[1]))
if __name__=='__main__':main()
