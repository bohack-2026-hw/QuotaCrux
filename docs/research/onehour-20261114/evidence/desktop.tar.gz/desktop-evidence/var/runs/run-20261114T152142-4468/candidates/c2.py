import sys, random, time

def main():
    data=list(map(int,sys.stdin.buffer.read().split()))
    n,m=data[:2]
    initial=[data[2+i*(n//m):2+(i+1)*(n//m)] for i in range(m)]
    rng=random.Random(91437)
    start=time.perf_counter()
    best=10**9
    answer=[]
    trials=0
    while trials<220 and (trials<10 or time.perf_counter()-start<1.55):
        trial=trials; trials+=1
        stacks=[s[:] for s in initial]
        loc=[0]*(n+1)
        for i,s in enumerate(stacks):
            for x in s: loc[x]=i
        mins=[min(s) if s else n+1 for s in stacks]
        if trial==0:
            tolerance=1000; mode=0; noise=0
        else:
            tolerance=[0,0,0,5,10,20,40,80,200][(trial-1)%9]
            mode=((trial-1)//9)%3
            noise=0 if trial<28 else rng.choice([2,5,10,20])
        ops=[]; cost=0
        for v in range(1,n+1):
            src=loc[v]; s=stacks[src]; p=s.index(v)
            while len(s)>p+1:
                k=len(s)-1
                while k>p+1 and s[k-1]+tolerance>=s[k]: k-=1
                chunk=s[k:]
                if mode==0: ref=max(chunk)
                elif mode==1: ref=chunk[0]
                else: ref=min(chunk)
                chosen=-1; key=1e30
                for j in range(m):
                    if j==src: continue
                    d=mins[j]
                    score=(d-ref if d>ref else 2*n+ref-d)
                    if noise: score+=rng.uniform(-noise,noise)
                    if score<key: key=score; chosen=j
                ops.append((chunk[0],chosen+1))
                cost+=len(chunk)+1
                stacks[chosen].extend(chunk)
                mins[chosen]=min(mins[chosen],min(chunk))
                for x in chunk: loc[x]=chosen
                del s[k:]
            s.pop(); mins[src]=min(s) if s else n+1
            ops.append((v,0))
            if cost>=best: break
        else:
            if cost<best:
                best=cost; answer=ops
    sys.stdout.write('\n'.join(f'{v} {d}' for v,d in answer))

if __name__=='__main__': main()
