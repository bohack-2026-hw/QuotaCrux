import sys, random, time, math

def main():
    data=list(map(int,sys.stdin.buffer.read().split()))
    n,m=data[:2]; width=n//m
    initial=[data[2+i*width:2+(i+1)*width] for i in range(m)]
    rng=random.Random(91437); start=time.perf_counter(); end=start+1.72
    best=10**9; answer=[]; bestplan=None; bestpar=None
    def solve(par, old=None, change=None, limit=100000):
        tol,mode,noise=par
        stacks=[s[:] for s in initial]; loc=[0]*(n+1)
        for i,s in enumerate(stacks):
            for x in s: loc[x]=i
        mins=[min(s) if s else n+1 for s in stacks]
        ops=[]; plan={}; cost=0
        for v in range(1,n+1):
            src=loc[v]; s=stacks[src]; p=s.index(v)
            while len(s)>p+1:
                key=v*(n+1)+s[-1]
                entry=change[1] if change is not None and key==change[0] else old.get(key) if old is not None else None
                k=-1; chosen=-1
                if entry is not None:
                    bottom,dest=entry
                    if dest!=src and bottom in s[p+1:]:
                        k=s.index(bottom,p+1); chosen=dest
                if k<0:
                    k=len(s)-1
                    while k>p+1 and s[k-1]+tol>=s[k]: k-=1
                    chunk=s[k:]
                    ref=max(chunk) if mode==0 else chunk[0] if mode==1 else min(chunk)
                    low=1e30
                    for j,d in enumerate(mins):
                        if j==src: continue
                        z=d-ref if d>ref else 2*n+ref-d
                        if noise: z+=rng.uniform(-noise,noise)
                        if z<low: low=z; chosen=j
                chunk=s[k:]; cost+=len(chunk)+1
                if cost>=limit: return None
                ops.append((chunk[0],chosen+1)); plan[key]=(chunk[0],chosen)
                stacks[chosen].extend(chunk); mins[chosen]=min(mins[chosen],min(chunk))
                for x in chunk: loc[x]=chosen
                del s[k:]
            s.pop(); mins[src]=min(s) if s else n+1; ops.append((v,0))
        return cost,ops,plan
    for trial in range(220):
        if trial>=35 and time.perf_counter()-start>0.48: break
        if trial==0: par=(1000,0,0)
        else: par=([0,0,0,5,10,20,40,80,200][(trial-1)%9],((trial-1)//9)%3,0 if trial<28 else rng.choice([2,5,10,20]))
        r=solve(par,limit=best)
        if r is not None:
            best,answer,bestplan=r; bestpar=par
    cur=best; plan=bestplan; par=(bestpar[0],bestpar[1],0)
    keys=list(plan); stagnation=0; iteration=0
    while time.perf_counter()<end:
        iteration+=1; stagnation+=1
        if stagnation>85:
            cur=best; plan=bestplan; keys=list(plan); stagnation=0
            par=(rng.choice([0,0,5,10,20,40]),rng.randrange(3),0)
        key=rng.choice(keys); bottom,dest=plan[key]; v=key//(n+1); top=key%(n+1)
        if rng.random()<0.68:
            nd=rng.randrange(m-1)
            if nd>=dest: nd+=1
            edit=(bottom,nd)
        else:
            edit=(top,rng.randrange(m))
        progress=(time.perf_counter()-start)/1.72
        temp=2.5*(1-progress)+0.15
        result=solve(par,plan,(key,edit),best+32)
        if result is None: continue
        cost,ops,np=result
        delta=cost-cur
        if delta<=0 or rng.random()<math.exp(-delta/temp):
            cur=cost; plan=np; keys=list(plan)
        if cost<best:
            best=cost; answer=ops; bestplan=np; bestpar=par; stagnation=0
    sys.stdout.write('\n'.join(f'{v} {d}' for v,d in answer))

if __name__=='__main__': main()
