import sys, random, time, math

def main():
    data=list(map(int,sys.stdin.buffer.read().split()))
    n,m=data[:2]; w=n//m
    initial=[data[2+i*w:2+(i+1)*w] for i in range(m)]
    rng=random.Random(91437); start=time.perf_counter(); deadline=start+1.77
    inf=n+1
    # A solution stores a checkpoint before removing each value.
    def solve(par, old=None, edit=None, limit=100000):
        tol,mode,noise=par
        v0=1 if edit is None else edit[0]
        if old is None:
            stacks=[s[:] for s in initial]; cost=0
            states=[None]; costs=[0]; plans=[None]; outputs=[None]
        else:
            states=old[1][:v0]; costs=old[2][:v0]
            plans=old[3][:v0]; outputs=old[4][:v0]
            stacks=[s[:] for s in old[1][v0]]; cost=old[2][v0]
        loc=[0]*(n+1)
        for j,s in enumerate(stacks):
            for x in s: loc[x]=j
        mins=[min(s) if s else inf for s in stacks]
        for v in range(v0,n+1):
            states.append([s[:] for s in stacks]); costs.append(cost)
            src=loc[v]; s=stacks[src]; p=s.index(v)
            previous=old[3][v] if old is not None else {}
            plan={}; ops=[]
            while len(s)>p+1:
                top=s[-1]; entry=previous.get(top)
                k=-1; dest=-1
                if entry is not None:
                    bottom,d=entry
                    if d!=src:
                        try: k=s.index(bottom,p+1); dest=d
                        except ValueError: pass
                if edit is not None and v==edit[0] and top==edit[1]:
                    kind,a,b=edit[2:]
                    if k<0: k=len(s)-1
                    if kind==0:
                        dest=a if a<src else a+1
                    elif kind==1:
                        k=p+1+a%(len(s)-p-1)
                    elif kind==2:
                        k=max(p+1,min(len(s)-1,k+a))
                    else:
                        k=p+1+a%(len(s)-p-1)
                        dest=-1
                if k<0:
                    k=len(s)-1
                    while k>p+1 and s[k-1]+tol>=s[k]: k-=1
                chunk=s[k:]
                if dest<0:
                    ref=max(chunk) if mode==0 else chunk[0] if mode==1 else min(chunk)
                    low=1e30
                    for j,d in enumerate(mins):
                        if j==src: continue
                        z=d-ref if d>ref else 2*n+ref-d
                        if noise: z+=rng.uniform(-noise,noise)
                        if z<low: low=z; dest=j
                cost+=len(chunk)+1
                if cost>=limit: return None
                ops.append((chunk[0],dest+1)); plan[top]=(chunk[0],dest)
                stacks[dest].extend(chunk)
                mins[dest]=min(mins[dest],min(chunk))
                for x in chunk: loc[x]=dest
                del s[k:]
            s.pop(); mins[src]=min(s) if s else inf
            ops.append((v,0)); plans.append(plan); outputs.append(ops)
        keys=[(v,t) for v in range(1,n+1) for t in plans[v]]
        return cost,states,costs,plans,outputs,keys
    best=100000; bestsol=None; bestpar=None
    for trial in range(180):
        if trial>=30 and time.perf_counter()-start>0.32: break
        if trial==0: par=(1000,0,0)
        else: par=([0,0,0,5,10,20,40,80,200][(trial-1)%9],((trial-1)//9)%3,0 if trial<28 else rng.choice([2,5,10,20]))
        result=solve(par,limit=best)
        if result is not None:
            best=result[0]; bestsol=result; bestpar=par
    current=bestsol; par=(bestpar[0],bestpar[1],0)
    stale=0; iterations=0
    while time.perf_counter()<deadline:
        iterations+=1; stale+=1
        if not current[5]: break
        if stale>220:
            current=bestsol; stale=0
            par=(rng.choice([0,0,0,5,10,20,40]),rng.randrange(3),0)
        v,top=rng.choice(current[5])
        r=rng.random()
        if r<0.55: edit=(v,top,0,rng.randrange(m-1),0)
        elif r<0.77: edit=(v,top,2,rng.choice([-2,-1,1,2]),0)
        elif r<0.94: edit=(v,top,1,rng.randrange(n),0)
        else: edit=(v,top,3,rng.randrange(n),0)
        result=solve(par,current,edit,best+30)
        if result is None: continue
        delta=result[0]-current[0]
        progress=min(1,(time.perf_counter()-start)/1.77)
        temp=2.8*(1-progress)+0.12
        if delta<=0 or rng.random()<math.exp(-delta/temp): current=result
        if result[0]<best:
            best=result[0]; bestsol=result; bestpar=par; stale=0
    out=[]
    for ops in bestsol[4][1:]:
        out.extend(f'{v} {d}' for v,d in ops)
    sys.stdout.write('\n'.join(out))

if __name__=='__main__': main()
