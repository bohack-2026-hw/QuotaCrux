import sys, random, time, math

def main():
    data=list(map(int,sys.stdin.buffer.read().split()))
    n,m=data[:2]; w=n//m
    initial=[tuple(data[2+i*w:2+(i+1)*w]) for i in range(m)]
    rng=random.Random(91437); start=time.perf_counter(); duration=1.77; deadline=start+duration; inf=n+1
    def solve(par, old=None, edit=None, limit=100000):
        tol,mode,noise=par
        v0=1 if edit is None else edit[0]
        if old is None:
            stacks=initial[:]; cost=0
            states=[None]; costs=[0]; plans=[None]; outputs=[None]
        else:
            states=old[1][:v0]; costs=old[2][:v0]; plans=old[3][:v0]; outputs=old[4][:v0]
            stacks=old[1][v0][:]; cost=old[2][v0]
        loc=[0]*(n+1)
        for j,s in enumerate(stacks):
            for x in s: loc[x]=j
        mins=[min(s) if s else inf for s in stacks]
        for v in range(v0,n+1):
            states.append(stacks[:]); costs.append(cost)
            src=loc[v]; s=stacks[src]; p=s.index(v)
            previous=old[3][v] if old is not None else {}
            plan={}; ops=[]
            while len(s)>p+1:
                top=s[-1]; entry=previous.get(top); k=-1; dest=-1
                if entry is not None:
                    bottom,d=entry
                    if d!=src:
                        try: k=s.index(bottom,p+1); dest=d
                        except ValueError: pass
                if edit is not None and v==edit[0] and top==edit[1]:
                    kind,a,b=edit[2:]
                    if k<0: k=len(s)-1
                    if kind==0:
                        dest=a
                    elif kind==1:
                        k=p+1+a%(len(s)-p-1)
                    elif kind==2:
                        k=max(p+1,min(len(s)-1,k+a))
                    elif kind==3:
                        k=p+1+a%(len(s)-p-1); dest=-1
                    else:
                        k=p+1+a%(len(s)-p-1); dest=b if b!=src else -1
                if k<0:
                    k=len(s)-1
                    while k>p+1 and s[k-1]+tol>=s[k]: k-=1
                chunk=s[k:]
                if dest<0:
                    ref=max(chunk) if mode==0 else chunk[0] if mode==1 else min(chunk)
                    low=1e30
                    for j,d in enumerate(mins):
                        if j==src: continue
                        z=d-ref if d>ref else 2*n+ref-d
                        if noise: z+=rng.uniform(-noise,noise)
                        if z<low: low=z; dest=j
                cost+=len(chunk)+1
                if cost>=limit: return None
                ops.append((chunk[0],dest+1)); plan[top]=(chunk[0],dest)
                stacks[dest]+=chunk; mins[dest]=min(mins[dest],min(chunk))
                for x in chunk: loc[x]=dest
                s=s[:k]
            s=s[:-1]; stacks[src]=s; mins[src]=min(s) if s else inf
            ops.append((v,0)); plans.append(plan); outputs.append(ops)
        return [cost,states,costs,plans,outputs,None]
    def keys(sol):
        if sol[5] is None: sol[5]=[(v,t) for v in range(1,n+1) for t in sol[3][v]]
        return sol[5]
    best=100000; bestsol=None; bestpar=None
    for trial in range(180):
        if trial>=30 and time.perf_counter()-start>0.25: break
        if trial==0: par=(1000,0,0)
        else: par=([0,0,0,5,10,20,40,80,200][(trial-1)%9],((trial-1)//9)%3,0 if trial<28 else rng.choice([2,5,10,20]))
        result=solve(par,limit=best)
        if result is not None: best=result[0]; bestsol=result; bestpar=par
    current=bestsol; par=(bestpar[0],bestpar[1],0); stale=0
    while time.perf_counter()<deadline:
        stale+=1
        kk=keys(current)
        if not kk: break
        if stale>350:
            current=bestsol; stale=0; par=(rng.choice([0,0,0,5,10,20,40]),rng.randrange(3),0); kk=keys(current)
        v,top=rng.choice(kk); bottom,prevdest=current[3][v][top]
        src=next(i for i,s in enumerate(current[1][v]) if v in s)
        r=rng.random()
        if r<0.54:
            dest=rng.randrange(m-2)
            for j in sorted((src,prevdest)):
                if dest>=j: dest+=1
            edit=(v,top,0,dest,0)
        elif r<0.75: edit=(v,top,2,rng.choice([-2,-1,1,2]),0)
        elif r<0.88: edit=(v,top,1,rng.randrange(n),0)
        elif r<0.96: edit=(v,top,3,rng.randrange(n),0)
        else: edit=(v,top,4,rng.randrange(n),rng.randrange(m))
        result=solve(par,current,edit,best+26)
        if result is None: continue
        delta=result[0]-current[0]
        progress=min(1,(time.perf_counter()-start)/duration); temp=2.5*(1-progress)+0.12
        if delta<=0 or rng.random()<math.exp(-delta/temp): current=result
        if result[0]<best:
            best=result[0]; bestsol=result; bestpar=par; stale=0
    out=[]
    for ops in bestsol[4][1:]: out.extend(f'{v} {d}' for v,d in ops)
    sys.stdout.write('\n'.join(out))

if __name__=='__main__': main()
