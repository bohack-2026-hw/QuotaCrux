import sys

def solve():
    data = list(map(int, sys.stdin.buffer.read().split()))
    n, m = data[0], data[1]
    idx = 2
    stacks = []
    for i in range(m):
        stack = data[idx:idx + n // m]
        idx += n // m
        stacks.append(stack)
    
    # Position map: box number -> (stack index, position in stack)
    pos = {}
    for i, stack in enumerate(stacks):
        for j, box in enumerate(stack):
            pos[box] = (i, j)
    
    operations = []
    
    def find_stack_of_box(box):
        return pos[box][0]
    
    def get_position_in_stack(box):
        return pos[box][1]
    
    for value in range(1, n + 1):
        src = pos[value][0]
        position = pos[value][1]
        
        if position + 1 < len(stacks[src]):
            above = stacks[src][position + 1:]
            
            # Find the best destination stack
            # Strategy: move boxes to a stack where they can be accessed soon
            # Prefer stacks that contain smaller numbered boxes below
            
            best_dest = -1
            best_score = float('inf')
            
            for dest in range(m):
                if dest == src:
                    continue
                
                # Score based on how well this destination helps
                # We want to minimize future moves
                # A good heuristic: put boxes on a stack where the next needed box is already there or nearby
                
                # Calculate the minimum box number in 'above'
                min_above = min(above)
                
                # Check if any box in 'above' has its predecessor in this dest stack
                # If so, it's a good place to put them
                
                score = len(stacks[dest])  # Prefer shorter stacks as tiebreaker
                
                # Better: check if placing these boxes here reduces future work
                # For each box in above, check if box-1 is in dest stack (below the new boxes)
                # If yes, that box will be accessible sooner
                
                helpful_count = 0
                for box in above:
                    if box > 1 and (box - 1) in pos:
                        dest_box_pos = pos[box - 1]
                        if dest_box_pos[0] == dest and dest_box_pos[1] < len(stacks[dest]):
                            helpful_count += 1
                
                # Also consider: if the smallest box in above is close to being taken out
                # from this destination
                
                total_score = -helpful_count * 100 + score
                
                if total_score < best_score:
                    best_score = total_score
                    best_dest = dest
            
            if best_dest == -1:
                best_dest = 0 if src != 0 else 1
            
            operations.append((above[0], best_dest + 1))
            
            # Update state
            moved_boxes = above
            stacks[best_dest].extend(moved_boxes)
            del stacks[src][position + 1:]
            
            # Update positions
            for j, box in enumerate(moved_boxes):
                pos[box] = (best_dest, len(stacks[best_dest]) - len(moved_boxes) + j)
            for j in range(position + 1):
                pos[stacks[src][j]] = (src, j)
        
        # Carry out the box
        operations.append((value, 0))
        
        # Remove box from stack
        stacks[src].pop()
        del pos[value]
        for j in range(len(stacks[src])):
            pos[stacks[src][j]] = (src, j)
    
    # Output operations
    out_lines = []
    for v, i in operations:
        out_lines.append(f"{v} {i}")
    print('\n'.join(out_lines))

solve()
