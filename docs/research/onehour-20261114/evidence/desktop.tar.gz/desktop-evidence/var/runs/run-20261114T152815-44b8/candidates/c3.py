import sys, time, random

def main():
    a=list(map(int,sys.stdin.buffer.read().split()))
    if not a:return
    n,m=a[:2]
    initial=[a[2+i*(n//m):2+(i+1)*(n//m)] for i in range(m)]
    rng=random.Random(26026)
    deadline=time.perf_counter()+1.60
    best=10**9
    bestops=[]
    rounds=0
    while rounds<1800 and (rounds<16 or time.perf_counter()<deadline):
        mode=rounds%4
        if rounds<16:
            alpha=[0.0,0.4,0.75,1.0][rounds//4]
            noise=0.0
        else:
            alpha=rng.choice([0.0,0.15,0.4,0.7,1.0])
            noise=rng.choice([0.0,0.5,2.0,5.0,12.0])
        merge=rng.choice([0.05,0.15,0.3,0.5])
        st=[s[:] for s in initial]
        where=[0]*(n+1)
        for i,s in enumerate(st):
            for v in s:where[v]=i
        mins=[min(s,default=n+1) for s in st]
        ops=[]
        energy=0
        for v in range(1,n+1):
            src=where[v]
            s=st[src]
            p=s.index(v)
            while len(s)>p+1:
                h=len(s)
                j=h-1
                if mode==0:
                    j=p+1
                else:
                    while j>p+1:
                        if s[j-1]>s[j] or (mode==3 and rng.random()<merge):j-=1
                        else:break
                chunk=s[j:]
                lo=min(chunk);hi=max(chunk)
                dest=-1
                if mode==2:
                    bs=-1e30
                    for d in range(m):
                        if d==src:continue
                        k=h-1
                        if s[k]<mins[d]:
                            while k>j and s[k-1]<mins[d]:k-=1
                            score=(h-k)*16.0-(mins[d]-s[k])*0.025
                        else:
                            score=-1000.0+mins[d]
                        score+=rng.random()*noise
                        if score>bs:
                            bs=score;dest=d;cut=k
                    j=cut
                    chunk=s[j:]
                    lo=min(chunk);hi=max(chunk)
                else:
                    ref=lo+alpha*(hi-lo)
                    bs=1e30
                    for d in range(m):
                        if d==src:continue
                        t=mins[d]
                        score=(t-ref) if t>ref else 1000+(ref-t)*3
                        score+=0.015*len(st[d])+rng.random()*noise
                        if score<bs:bs=score;dest=d
                ops.append((s[j],dest+1))
                energy+=h-j+1
                st[dest].extend(chunk)
                mins[dest]=min(mins[dest],lo)
                for x in chunk:where[x]=dest
                del s[j:]
            s.pop()
            mins[src]=min(s,default=n+1)
            ops.append((v,0))
            if energy>=best:break
        else:
            if energy<best:
                best=energy;bestops=ops
        rounds+=1
    sys.stdout.write('\n'.join(str(v)+' '+str(d) for v,d in bestops))

if __name__=='__main__':main()
