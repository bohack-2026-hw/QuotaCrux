import sys,time,random,math

def main():
    a=list(map(int,sys.stdin.buffer.read().split()))
    if not a:return
    n,m=a[:2]
    initial=[a[2+i*(n//m):2+(i+1)*(n//m)] for i in range(m)]
    rng=random.Random(26026)
    start=time.perf_counter()
    deadline=start+1.76
    best=10**9
    bestplan=None
    bestops=None

    def simulate(old,mut,mode,alpha,noise,merge,limit):
        st=[s[:] for s in initial]
        where=[0]*(n+1)
        for i,s in enumerate(st):
            for x in s:where[x]=i
        mins=[min(s,default=n+1) for s in st]
        plan=[None]*(n+1)
        ops=[]
        energy=0
        for v in range(1,n+1):
            src=where[v];s=st[src];p=s.index(v)
            actions=[]
            if old is not None and v not in mut:
                for box,d in old[v]:
                    if d==src or len(s)<=p+1:continue
                    try:j=s.index(box,p+1)
                    except ValueError:continue
                    chunk=s[j:]
                    energy+=len(chunk)+1
                    if energy>limit:return None
                    st[d].extend(chunk)
                    mins[d]=min(mins[d],min(chunk))
                    for x in chunk:where[x]=d
                    del s[j:]
                    actions.append((box,d));ops.append((box,d+1))
            while len(s)>p+1:
                h=len(s);j=h-1
                if mode==0:j=p+1
                else:
                    while j>p+1:
                        if s[j-1]>s[j] or (mode==3 and rng.random()<merge):j-=1
                        else:break
                chunk=s[j:];lo=min(chunk);hi=max(chunk)
                dest=-1
                if mode==2:
                    bs=-1e30;cut=j
                    for d in range(m):
                        if d==src:continue
                        k=h-1
                        if s[k]<mins[d]:
                            while k>j and s[k-1]<mins[d]:k-=1
                            score=(h-k)*16.0-(mins[d]-s[k])*0.025
                        else:score=-1000.0+mins[d]
                        score+=rng.random()*noise
                        if score>bs:bs=score;dest=d;cut=k
                    j=cut;chunk=s[j:];lo=min(chunk)
                else:
                    ref=lo+alpha*(hi-lo);bs=1e30
                    for d in range(m):
                        if d==src:continue
                        t=mins[d]
                        score=(t-ref) if t>ref else 1000+(ref-t)*3
                        score+=0.015*len(st[d])+rng.random()*noise
                        if score<bs:bs=score;dest=d
                box=s[j]
                actions.append((box,dest));ops.append((box,dest+1))
                energy+=h-j+1
                if energy>limit:return None
                st[dest].extend(chunk)
                mins[dest]=min(mins[dest],lo)
                for x in chunk:where[x]=dest
                del s[j:]
            plan[v]=actions
            s.pop();mins[src]=min(s,default=n+1)
            ops.append((v,0))
        return energy,plan,ops

    rounds=0
    while rounds<1800 and (rounds<16 or time.perf_counter()<start+0.43):
        mode=rounds%4
        if rounds<16:alpha=[0.0,0.4,0.75,1.0][rounds//4];noise=0.0
        else:
            alpha=rng.choice([0.0,0.15,0.4,0.7,1.0])
            noise=rng.choice([0.0,0.5,2.0,5.0,12.0])
        merge=rng.choice([0.05,0.15,0.3,0.5])
        result=simulate(None,(),mode,alpha,noise,merge,best)
        if result is not None and result[0]<best:best,bestplan,bestops=result
        rounds+=1
    current=best;curplan=bestplan
    active=[v for v in range(1,n+1) if curplan[v]]
    iteration=0
    while time.perf_counter()<deadline:
        if not active:break
        v=rng.choice(active)
        mut={v}
        if rng.random()<0.22:mut.add(rng.choice(active))
        if rng.random()<0.05:mut.add(rng.choice(active))
        mode=rng.choice([0,1,1,1,2,2,3])
        alpha=rng.choice([0.0,0.2,0.5,0.8,1.0])
        noise=rng.choice([0.0,3.0,10.0,25.0,60.0,120.0])
        merge=rng.choice([0.02,0.1,0.25,0.5])
        progress=(time.perf_counter()-start)/1.76
        temp=2.5*(1-progress)+0.2
        result=simulate(curplan,mut,mode,alpha,noise,merge,current+int(8*temp)+1)
        if result is not None:
            cost,pl,op=result
            if cost<best:best=cost;bestplan=pl;bestops=op
            if cost<=current or rng.random()<math.exp((current-cost)/temp):
                current=cost;curplan=pl
                active=[x for x in range(1,n+1) if curplan[x]]
        iteration+=1
        if iteration%90==0:
            current=best;curplan=bestplan
            active=[x for x in range(1,n+1) if curplan[x]]
    sys.stdout.write('\n'.join(str(v)+' '+str(d) for v,d in bestops))

if __name__=='__main__':main()
