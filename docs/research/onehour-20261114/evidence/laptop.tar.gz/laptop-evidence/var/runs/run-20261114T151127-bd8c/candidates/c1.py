import sys

def solve():
    data = list(map(int, sys.stdin.buffer.read().split()))
    it = iter(data)
    n = next(it); m = next(it)
    h = n // m
    stacks = [[next(it) for _ in range(h)] for _ in range(m)]
    
    # Precompute positions: pos[v] = (stack_index, position_in_stack)
    pos = [None] * (n + 1)
    for i in range(m):
        for j, v in enumerate(stacks[i]):
            pos[v] = (i, j)
    
    ops = []
    
    def move_above(v, dest):
        """Move all boxes above v in its current stack to dest. Returns energy cost."""
        src_i, src_j = pos[v]
        if src_j + 1 >= len(stacks[src_i]):
            return 0
        above = stacks[src_i][src_j+1:]
        k = len(above)
        # Update positions for moved boxes
        for idx, box in enumerate(above):
            pos[box] = (dest, len(stacks[dest]) + idx)
        stacks[dest].extend(above)
        del stacks[src_i][src_j+1:]
        ops.append((above[0], dest + 1))
        return k + 1
    
    total_energy = 0
    
    for v in range(1, n + 1):
        src_i, src_j = pos[v]
        # Check if there are boxes above v
        if src_j + 1 < len(stacks[src_i]):
            # Need to move boxes above v
            # Choose best destination: minimize future cost
            # Heuristic: choose dest where the topmost box is largest (so it's less likely to be needed soon)
            # Or: choose dest that has fewest boxes (to keep stacks balanced)
            # Better heuristic: simulate - for each candidate dest, estimate how many additional moves will be needed
            
            best_dest = -1
            best_score = float('inf')
            
            for dest in range(m):
                if dest == src_i:
                    continue
                # Score: prefer dest with smaller max value at top (so we don't block small values)
                # Actually, we want to move boxes above v to a place where they won't interfere.
                # The boxes above v have values > v (since we're processing in order).
                # So moving them to any stack is fine as long as they don't block smaller values.
                # Since all remaining unprocessed boxes have value >= v+1, and the boxes above v also have value > v,
                # the key is: after moving, when we need to process those boxes, how much extra work?
                
                # Simple heuristic: choose dest with minimum length (balanced)
                score = len(stacks[dest])
                # Tie-breaker: choose dest where the top box has the largest value (least urgent)
                if stacks[dest]:
                    score -= 0  # no adjustment for now
                
                if score < best_score or (score == best_score and best_dest != -1 and (not stacks[best_dest] or not stacks[dest] or stacks[dest][-1] > stacks[best_dest][-1])):
                    best_score = score
                    best_dest = dest
            
            energy = move_above(v, best_dest)
            total_energy += energy
        
        # Now v should be at top of src_i
        assert pos[v] == (src_i, len(stacks[src_i]) - 1), f"Box {v} not at top"
        ops.append((v, 0))
        stacks[src_i].pop()
        pos[v] = None
    
    # Output operations
    out = []
    for v, i in ops:
        out.append(f"{v} {i}")
    print('\n'.join(out))

solve()