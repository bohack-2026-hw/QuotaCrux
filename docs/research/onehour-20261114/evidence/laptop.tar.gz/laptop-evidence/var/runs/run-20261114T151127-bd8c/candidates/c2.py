import sys

def solve():
    data = list(map(int, sys.stdin.buffer.read().split()))
    it = iter(data)
    n = next(it); m = next(it)
    h = n // m
    stacks = [[next(it) for _ in range(h)] for _ in range(m)]
    
    # Precompute positions: pos[v] = (stack_index, position_in_stack)
    pos = [None] * (n + 1)
    for i in range(m):
        for j, v in enumerate(stacks[i]):
            pos[v] = (i, j)
    
    ops = []
    total_energy = 0
    
    def move_above(v, dest):
        """Move all boxes above v in its current stack to dest. Returns energy cost."""
        src_i, src_j = pos[v]
        if src_j + 1 >= len(stacks[src_i]):
            return 0
        above = stacks[src_i][src_j+1:]
        k = len(above)
        # Update positions for moved boxes
        for idx, box in enumerate(above):
            pos[box] = (dest, len(stacks[dest]) + idx)
        stacks[dest].extend(above)
        del stacks[src_i][src_j+1:]
        ops.append((above[0], dest + 1))
        return k + 1
    
    for v in range(1, n + 1):
        src_i, src_j = pos[v]
        # Check if there are boxes above v
        if src_j + 1 < len(stacks[src_i]):
            # Need to move boxes above v
            # Choose best destination: minimize future cost
            # Heuristic: choose dest where the minimum value among boxes above v is maximized
            # This means the moved boxes are less likely to be needed soon
            
            above_boxes = stacks[src_i][src_j+1:]
            min_above = min(above_boxes)
            
            best_dest = -1
            best_score = float('-inf')
            
            for dest in range(m):
                if dest == src_i:
                    continue
                # Score: prefer dest with smaller length (balanced)
                # Also consider: if we move to a stack that already has small values, it might cause more issues
                score = -len(stacks[dest])
                
                # If the destination stack's top has a value larger than min_above, it's better
                # because those boxes won't interfere as much
                if stacks[dest]:
                    top_val = stacks[dest][-1]
                    if top_val > min_above:
                        score += 1
                
                if score > best_score or (score == best_score and best_dest != -1 and (
                    not stacks[best_dest] or not stacks[dest] or 
                    (stacks[dest] and stacks[best_dest] and stacks[dest][-1] > stacks[best_dest][-1])
                )):
                    best_score = score
                    best_dest = dest
            
            energy = move_above(v, best_dest)
            total_energy += energy
        
        # Now v should be at top of src_i
        assert pos[v] == (src_i, len(stacks[src_i]) - 1), f"Box {v} not at top"
        ops.append((v, 0))
        stacks[src_i].pop()
        pos[v] = None
    
    # Output operations
    out = []
    for v, i in ops:
        out.append(f"{v} {i}")
    print('\n'.join(out))

solve()