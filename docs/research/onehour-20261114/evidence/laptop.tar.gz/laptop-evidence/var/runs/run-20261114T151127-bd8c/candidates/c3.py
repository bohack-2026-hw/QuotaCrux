import sys, time, random

def solve():
    start = time.perf_counter()
    a = list(map(int, sys.stdin.buffer.read().split()))
    if not a:
        return
    n, m = a[:2]
    h = n // m
    original = [a[2+i*h:2+(i+1)*h] for i in range(m)]
    rng = random.Random(726381)
    best_energy = 10**9
    best_ops = None

    def trial(mode, alpha, limit, noise, height_weight):
        nonlocal best_energy, best_ops
        stacks = [s[:] for s in original]
        loc = [0]*(n+1)
        for i,s in enumerate(stacks):
            for x in s:
                loc[x] = i
        mins = [min(s) if s else n+1 for s in stacks]
        ops = []
        energy = 0
        for v in range(1,n+1):
            src = loc[v]
            s = stacks[src]
            p = s.index(v)
            while len(s)>p+1:
                end = len(s)
                j = p+1
                if mode == 1:
                    j = end-1
                    while j>p+1 and s[j-1] >= s[j] and end-j < limit:
                        j -= 1
                elif mode == 2:
                    j = max(p+1,end-limit)
                elif mode == 3:
                    x = s[-1]
                    bd = -1
                    bs = 1e20
                    for d in range(m):
                        if d == src:
                            continue
                        z = mins[d]
                        score = z-x if z>x else 2*n-z
                        score += height_weight*len(stacks[d])
                        if noise:
                            score += rng.random()*noise
                        if score<bs:
                            bs=score; bd=d
                    threshold = max(x, mins[bd]-1)
                    j=end-1
                    while j>p+1 and s[j-1]<=threshold and end-j<limit:
                        j-=1
                chunk = s[j:]
                lo = min(chunk)
                hi = max(chunk)
                target = lo + alpha*(hi-lo)
                if mode == 4:
                    target = sum(chunk)/len(chunk)
                bd=-1
                bs=1e20
                for d in range(m):
                    if d==src:
                        continue
                    z=mins[d]
                    score = z-target if z>target else 2*n-z
                    score += height_weight*len(stacks[d])
                    if noise:
                        score += rng.random()*noise
                    if score<bs:
                        bs=score; bd=d
                ops.append((chunk[0],bd+1))
                energy += len(chunk)+1
                if energy>=best_energy:
                    return
                stacks[bd].extend(chunk)
                for x in chunk:
                    loc[x]=bd
                if lo<mins[bd]:
                    mins[bd]=lo
                del s[j:]
            s.pop()
            mins[src]=min(s) if s else n+1
            ops.append((v,0))
        if energy<best_energy:
            best_energy=energy
            best_ops=ops

    for mode in (0,1,3,2,4):
        for alpha in (0.0,0.5,1.0):
            for limit in ((3,6,12) if mode==2 else (n,)):
                trial(mode,alpha,limit,0,0)
    count=0
    while time.perf_counter()-start<1.55 and count<500:
        count+=1
        mode=rng.choice((0,1,2,3,3,4))
        alpha=rng.choice((0.0,0.2,0.4,0.6,0.8,1.0))
        limit=rng.choice((2,3,4,6,10,20,n)) if mode in (1,2,3) else n
        noise=rng.choice((0,2,5,10,20,35))
        hw=rng.choice((0,0,0,0.2,0.5,1.0,-0.2))
        trial(mode,alpha,limit,noise,hw)
    sys.stdout.write('\n'.join(str(v)+' '+str(d) for v,d in best_ops))

if __name__=='__main__':
    solve()
