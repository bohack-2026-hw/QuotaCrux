import sys,time,random

def solve():
    start=time.perf_counter()
    a=list(map(int,sys.stdin.buffer.read().split()))
    if not a:return
    n,m=a[:2];h=n//m
    original=[a[2+i*h:2+(i+1)*h] for i in range(m)]
    rng=random.Random(726381)
    best_energy=10**9;best_plans=None

    def trial(mode,alpha,limit,noise,hw):
        nonlocal best_energy,best_plans
        stacks=[s[:] for s in original]
        loc=[0]*(n+1)
        for i,s in enumerate(stacks):
            for x in s:loc[x]=i
        mins=[min(s) if s else n+1 for s in stacks]
        plans=[[] for _ in range(n+1)];energy=0
        for v in range(1,n+1):
            src=loc[v];s=stacks[src];p=s.index(v)
            while len(s)>p+1:
                end=len(s);j=p+1
                if mode==1:
                    j=end-1
                    while j>p+1 and s[j-1]>=s[j] and end-j<limit:j-=1
                elif mode==2:j=max(p+1,end-limit)
                elif mode==3:
                    x=s[-1];bd=-1;bs=1e20
                    for d in range(m):
                        if d==src:continue
                        z=mins[d];score=z-x if z>x else 2*n-z
                        score+=hw*len(stacks[d])
                        if noise:score+=rng.random()*noise
                        if score<bs:bs=score;bd=d
                    threshold=max(x,mins[bd]-1);j=end-1
                    while j>p+1 and s[j-1]<=threshold and end-j<limit:j-=1
                chunk=s[j:];lo=min(chunk);hi=max(chunk)
                target=lo+alpha*(hi-lo)
                if mode==4:target=sum(chunk)/len(chunk)
                bd=-1;bs=1e20
                for d in range(m):
                    if d==src:continue
                    z=mins[d];score=z-target if z>target else 2*n-z
                    score+=hw*len(stacks[d])
                    if noise:score+=rng.random()*noise
                    if score<bs:bs=score;bd=d
                plans[v].append((chunk[0],bd))
                energy+=len(chunk)+1
                if energy>=best_energy:return
                stacks[bd].extend(chunk)
                for x in chunk:loc[x]=bd
                mins[bd]=min(mins[bd],lo)
                del s[j:]
            s.pop();mins[src]=min(s) if s else n+1
        if energy<best_energy:best_energy=energy;best_plans=plans

    for mode in (0,1,3,2,4):
        for alpha in (0.,0.5,1.):
            for limit in ((3,6,12) if mode==2 else (n,)):
                trial(mode,alpha,limit,0,0)
    count=0
    while time.perf_counter()-start<0.48 and count<160:
        count+=1;mode=rng.choice((0,1,2,3,3,4))
        trial(mode,rng.choice((0.,0.2,0.4,0.6,0.8,1.)),rng.choice((2,3,4,6,10,20,n)) if mode in (1,2,3) else n,rng.choice((0,2,5,10,20,35)),rng.choice((0,0,0,0.2,0.5,1.,-0.2)))

    def snapshots(plans):
        st=[s[:] for s in original];loc=[0]*(n+1)
        for i,s in enumerate(st):
            for x in s:loc[x]=i
        states=[None]*(n+1);costs=[0]*(n+1);choices=[];energy=0
        for v in range(1,n+1):
            states[v]=[s[:] for s in st];costs[v]=energy
            src=loc[v];s=st[src]
            for t,(box,d) in enumerate(plans[v]):
                choices.append((v,t));j=s.index(box);chunk=s[j:]
                energy+=len(chunk)+1;st[d].extend(chunk)
                for x in chunk:loc[x]=d
                del s[j:]
            s.pop()
        return states,costs,choices

    states,costs,choices=snapshots(best_plans)
    while time.perf_counter()-start<1.76:
        if not choices:break
        v0,t0=rng.choice(choices)
        stacks=[s[:] for s in states[v0]]
        loc=[0]*(n+1)
        for i,s in enumerate(stacks):
            for x in s:loc[x]=i
        mins=[min(s) if s else n+1 for s in stacks]
        energy=costs[v0];newplans=best_plans[:v0]+[[] for _ in range(n-v0+1)]
        kind=rng.randrange(4);failed=False
        fallback_mode=rng.choice((0,1,3,3,3))
        alpha=rng.choice((0.,0.,0.5,1.));limit=rng.choice((4,10,n,n))
        for v in range(v0,n+1):
            src=loc[v];s=stacks[src];p=s.index(v)
            for t,(box,d) in enumerate(best_plans[v]):
                if len(s)<=p+1:break
                try:j=s.index(box,p+1)
                except ValueError:continue
                if v==v0 and t==t0:
                    if kind in (1,2,3):
                        if rng.random()<0.5:j=rng.randrange(p+1,len(s))
                        else:j=max(p+1,min(len(s)-1,j+rng.choice((-3,-2,-1,1,2,3))))
                    if kind!=1:
                        d=rng.randrange(m-1)
                        if d>=src:d+=1
                if d==src:continue
                chunk=s[j:];energy+=len(chunk)+1
                if energy>best_energy:failed=True;break
                newplans[v].append((chunk[0],d));stacks[d].extend(chunk)
                for x in chunk:loc[x]=d
                mins[d]=min(mins[d],min(chunk));del s[j:]
            if failed:break
            while len(s)>p+1:
                end=len(s);j=p+1
                if fallback_mode==1:
                    j=end-1
                    while j>p+1 and s[j-1]>=s[j] and end-j<limit:j-=1
                elif fallback_mode==3:
                    x=s[-1];bd=-1;bs=1e20
                    for d in range(m):
                        if d==src:continue
                        z=mins[d];sc=z-x if z>x else 2*n-z
                        if sc<bs:bs=sc;bd=d
                    threshold=max(x,mins[bd]-1);j=end-1
                    while j>p+1 and s[j-1]<=threshold and end-j<limit:j-=1
                chunk=s[j:];lo=min(chunk);hi=max(chunk);target=lo+alpha*(hi-lo)
                bd=-1;bs=1e20
                for d in range(m):
                    if d==src:continue
                    z=mins[d];sc=z-target if z>target else 2*n-z
                    if sc<bs:bs=sc;bd=d
                energy+=len(chunk)+1
                if energy>best_energy:failed=True;break
                newplans[v].append((chunk[0],bd));stacks[bd].extend(chunk)
                for x in chunk:loc[x]=bd
                mins[bd]=min(mins[bd],lo);del s[j:]
            if failed:break
            s.pop();mins[src]=min(s) if s else n+1
        if not failed and (energy<best_energy or (energy==best_energy and rng.random()<0.08)):
            best_energy=energy;best_plans=newplans
            states,costs,choices=snapshots(best_plans)
    out=[]
    for v in range(1,n+1):
        for x,d in best_plans[v]:out.append(str(x)+' '+str(d+1))
        out.append(str(v)+' 0')
    sys.stdout.write('\n'.join(out))

if __name__=='__main__':solve()
