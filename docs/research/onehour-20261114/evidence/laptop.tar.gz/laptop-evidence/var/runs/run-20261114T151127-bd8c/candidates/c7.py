import sys,time,random,math

def solve():
    start=time.perf_counter()
    a=list(map(int,sys.stdin.buffer.read().split()))
    if not a:return
    n,m=a[:2];h=n//m
    original=[a[2+i*h:2+(i+1)*h] for i in range(m)]
    rng=random.Random(726381)
    best_energy=10**9;best_plans=None
    def trial(mode,alpha,limit,noise,hw):
        nonlocal best_energy,best_plans
        stacks=[s[:] for s in original];loc=[0]*(n+1)
        for i,s in enumerate(stacks):
            for x in s:loc[x]=i
        mins=[min(s) if s else n+1 for s in stacks]
        plans=[[] for _ in range(n+1)];energy=0
        for v in range(1,n+1):
            src=loc[v];s=stacks[src];p=s.index(v)
            while len(s)>p+1:
                end=len(s);j=p+1
                if mode==1:
                    j=end-1
                    while j>p+1 and s[j-1]>=s[j] and end-j<limit:j-=1
                elif mode==2:j=max(p+1,end-limit)
                elif mode==3:
                    x=s[-1];bd=-1;bs=1e20
                    for d in range(m):
                        if d==src:continue
                        z=mins[d];score=z-x if z>x else 2*n-z
                        score+=hw*len(stacks[d])
                        if noise:score+=rng.random()*noise
                        if score<bs:bs=score;bd=d
                    threshold=max(x,mins[bd]-1);j=end-1
                    while j>p+1 and s[j-1]<=threshold and end-j<limit:j-=1
                chunk=s[j:];lo=min(chunk);hi=max(chunk);target=lo+alpha*(hi-lo)
                if mode==4:target=sum(chunk)/len(chunk)
                bd=-1;bs=1e20
                for d in range(m):
                    if d==src:continue
                    z=mins[d];score=z-target if z>target else 2*n-z
                    score+=hw*len(stacks[d])
                    if noise:score+=rng.random()*noise
                    if score<bs:bs=score;bd=d
                plans[v].append((chunk[0],bd));energy+=len(chunk)+1
                if energy>=best_energy:return
                stacks[bd].extend(chunk)
                for x in chunk:loc[x]=bd
                mins[bd]=min(mins[bd],lo);del s[j:]
            s.pop();mins[src]=min(s) if s else n+1
        if energy<best_energy:best_energy=energy;best_plans=plans
    for mode in (0,1,3,2,4):
        for alpha in (0.,0.5,1.):
            for limit in ((3,6,12) if mode==2 else (n,)):
                trial(mode,alpha,limit,0,0)
    count=0
    while time.perf_counter()-start<0.19 and count<65:
        count+=1;mode=rng.choice((0,1,2,3,3,4))
        trial(mode,rng.choice((0.,0.2,0.4,0.6,0.8,1.)),rng.choice((2,3,4,6,10,20,n)) if mode in (1,2,3) else n,rng.choice((0,2,5,10,20,35)),rng.choice((0,0,0,0.2,0.5,1.,-0.2)))
    def snapshots(plans):
        st=[s[:] for s in original];loc=[0]*(n+1)
        for i,s in enumerate(st):
            for x in s:loc[x]=i
        mins=[min(s) if s else n+1 for s in st]
        states=[None]*(n+2);locations=[None]*(n+2);minimums=[None]*(n+2)
        costs=[0]*(n+2);choices=[];energy=0
        for v in range(1,n+1):
            states[v]=[s[:] for s in st];locations[v]=loc[:];minimums[v]=mins[:];costs[v]=energy
            src=loc[v];s=st[src]
            for t,(box,d) in enumerate(plans[v]):
                choices.append((v,t));j=s.index(box);chunk=s[j:]
                energy+=len(chunk)+1;st[d].extend(chunk)
                for x in chunk:loc[x]=d
                mins[d]=min(mins[d],min(chunk));del s[j:]
            s.pop();mins[src]=min(s) if s else n+1
        costs[n+1]=energy;states[n+1]=[s[:] for s in st]
        return states,locations,minimums,costs,choices
    current=best_plans;current_energy=best_energy
    states,locations,minimums,costs,choices=snapshots(current)
    search_start=time.perf_counter();deadline=start+1.43
    iterations=0;last_improve=0
    while time.perf_counter()<deadline:
        if not choices:break
        iterations+=1
        progress=(time.perf_counter()-search_start)/max(0.01,deadline-search_start)
        temp=0.7*(1.0-progress)**2+0.02
        v0,t0=rng.choice(choices)
        stacks=[s[:] for s in states[v0]];loc=locations[v0][:];mins=minimums[v0][:]
        energy=costs[v0];newplans=current[:v0]+[[] for _ in range(n-v0+1)]
        kind=rng.randrange(6);failed=False
        fallback_mode=rng.choice((0,1,3,3,3))
        alpha=rng.choice((0.,0.,0.5,1.));limit=rng.choice((4,10,n,n))
        bound=min(current_energy+max(0,5*temp),best_energy+6)
        for v in range(v0,n+1):
            src=loc[v];s=stacks[src];p=s.index(v)
            for t,(box,d) in enumerate(current[v]):
                if len(s)<=p+1:break
                if v==v0 and t>=t0 and kind==5:break
                if v==v0 and t==t0 and kind==4:continue
                try:j=s.index(box,p+1)
                except ValueError:continue
                if v==v0 and t==t0:
                    oldj=j;oldd=d
                    if kind in (1,2,3):
                        if kind==3:j=p+1
                        elif rng.random()<0.5:j=rng.randrange(p+1,len(s))
                        else:j=max(p+1,min(len(s)-1,j+rng.choice((-3,-2,-1,1,2,3))))
                    if kind in (0,2,3):
                        if rng.random()<0.65:
                            d=rng.randrange(m-1)
                            if d>=src:d+=1
                        else:
                            chunk=s[j:];lo=min(chunk);hi=max(chunk)
                            target=lo+rng.choice((0.,0.5,1.))*(hi-lo)
                            bs=1e20
                            for dd in range(m):
                                if dd==src:continue
                                z=mins[dd];sc=(z-target if z>target else 2*n-z)+rng.random()*35
                                if sc<bs:bs=sc;d=dd
                    if oldj==j and oldd==d:failed=True;break
                if d==src:continue
                chunk=s[j:];energy+=len(chunk)+1
                if energy>bound:failed=True;break
                newplans[v].append((chunk[0],d));stacks[d].extend(chunk)
                for x in chunk:loc[x]=d
                mins[d]=min(mins[d],min(chunk));del s[j:]
            if failed:break
            while len(s)>p+1:
                end=len(s);j=p+1
                if fallback_mode==1:
                    j=end-1
                    while j>p+1 and s[j-1]>=s[j] and end-j<limit:j-=1
                elif fallback_mode==3:
                    x=s[-1];bd=-1;bs=1e20
                    for d in range(m):
                        if d==src:continue
                        z=mins[d];sc=z-x if z>x else 2*n-z
                        if sc<bs:bs=sc;bd=d
                    threshold=max(x,mins[bd]-1);j=end-1
                    while j>p+1 and s[j-1]<=threshold and end-j<limit:j-=1
                chunk=s[j:];lo=min(chunk);hi=max(chunk);target=lo+alpha*(hi-lo)
                bd=-1;bs=1e20
                for d in range(m):
                    if d==src:continue
                    z=mins[d];sc=z-target if z>target else 2*n-z
                    if sc<bs:bs=sc;bd=d
                energy+=len(chunk)+1
                if energy>bound:failed=True;break
                newplans[v].append((chunk[0],bd));stacks[bd].extend(chunk)
                for x in chunk:loc[x]=bd
                mins[bd]=min(mins[bd],lo);del s[j:]
            if failed:break
            s.pop();mins[src]=min(s) if s else n+1
            if stacks==states[v+1]:
                energy+=current_energy-costs[v+1]
                newplans[v+1:]=current[v+1:]
                break
        if not failed and energy<=bound:
            delta=energy-current_energy
            if delta<0 or (delta==0 and rng.random()<0.10) or (delta>0 and rng.random()<math.exp(-delta/temp)):
                current=newplans;current_energy=energy
                if energy<best_energy:
                    best_energy=energy;best_plans=newplans;last_improve=iterations
                states,locations,minimums,costs,choices=snapshots(current)
        if current_energy>best_energy and iterations-last_improve>220:
            current=best_plans;current_energy=best_energy
            states,locations,minimums,costs,choices=snapshots(current);last_improve=iterations
    out=[]
    for v in range(1,n+1):
        for x,d in best_plans[v]:out.append(str(x)+' '+str(d+1))
        out.append(str(v)+' 0')
    sys.stdout.write('\n'.join(out))
if __name__=='__main__':solve()
