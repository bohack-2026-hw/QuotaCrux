import sys

def solve():
    it = iter(map(int, sys.stdin.buffer.read().split()))
    n, m = next(it), next(it)
    stacks = [[next(it) for _ in range(n // m)] for _ in range(m)]
    
    # Precompute position of each box for O(1) lookup
    pos = {}
    for i, stack in enumerate(stacks):
        for j, val in enumerate(stack):
            pos[val] = (i, j)
    
    ops = []
    for value in range(1, n + 1):
        src_idx, pos_idx = pos[value]
        if pos_idx + 1 < len(stacks[src_idx]):
            above = stacks[src_idx][pos_idx + 1:]
            # Choose destination stack to minimize future cost.
            # Heuristic: choose the stack with the smallest top element (if any),
            # or the shortest stack if all are empty.
            best_dest = -1
            best_score = float('inf')
            for j in range(m):
                if j == src_idx:
                    continue
                if not stacks[j]:
                    score = 0 # Empty stack is always a good choice? Or maybe we want to keep them empty?
                    # Actually, moving to an empty stack is safe but might not be optimal if we can merge.
                    # Let's try: prefer stacks where the top box is smaller than 'value' ? No, that doesn't make sense.
                    # If top box is smaller, it will be removed soon, freeing space. That's good.
                    # So we want min(top_box).
                    # If stack is empty, top_box is infinity? Or 0?
                    # Let's say empty stack has score 0 (best) because it's clean.
                    # Wait, if I move to an empty stack, I create a new "group". 
                    # If I move to a non-empty stack, I might merge groups.
                    # Merging is generally better to reduce number of active stacks.
                    # But if the stack has small numbers on top, they will be cleared quickly.
                    pass
            
            # Let's refine the heuristic.
            # We want to move `above` to a stack such that these boxes are moved as few times as possible.
            # This happens if the destination stack is "active" and its boxes are removed soon.
            # A good proxy is: choose the stack with the minimum top element.
            # Why? Because the top element will be removed first (if it's the global min among remaining).
            # Actually, the global min is `value`. The next global min is `value+1`.
            # If we put `above` on a stack whose top is `x`, and `x` is small, then `x` will be removed soon,
            # potentially revealing more boxes below it, or just shortening the stack.
            
            # Let's try: Minimize the top element of the destination stack.
            # If stack is empty, treat top element as infinity (we don't want to create new stacks if avoidable, unless necessary).
            # Wait, if all stacks are full, we MUST move something.
            # Here we are moving `above` FROM `src`. `src` becomes shorter. So there is space.
            # We should prefer merging into existing stacks to keep the number of occupied stacks low?
            # Or spread out to keep stacks short?
            # Shorter stacks mean less energy per move (k+1).
            # So keeping stacks short is good.
            # Therefore, choosing the SHORTEST stack was actually a decent heuristic for minimizing k.
            # But c0 uses shortest stack. It got ~8800.
            
            # What if we combine: Choose the shortest stack. Among ties, choose the one with smallest top element?
            # Or: Choose the stack that minimizes (len(stack) * 1000 + top_element)?
            
            let's try: minimize (len(stacks[j]), top_element_of_stacks[j])
            
            candidates = []
            for j in range(m):
                if j == src_idx:
                    continue
                l = len(stacks[j])
                t = stacks[j][-1] if l > 0 else float('inf')
                candidates.append((l, t, j))
            
            candidates.sort()
            dest_idx = candidates[0][2]
            
            ops.append((above[0], dest_idx + 1))
            
            # Update state
            stacks[dest_idx].extend(above)
            del stacks[src_idx][pos_idx + 1:]
            
            # Update positions for moved boxes
            for k, box_val in enumerate(above):
                pos[box_val] = (dest_idx, len(stacks[dest_idx]) - len(above) + k)
            
            # Update position of 'value' in src (it didn't move, but index might have changed? No, it's at pos_idx, and we deleted after it)
            # pos[value] remains (src_idx, pos_idx) which is correct since we only deleted elements AFTER it.
            # Wait, if we delete elements after pos_idx, the indices of elements BEFORE pos_idx don't change.
            # So pos[value] is still valid.
            
        ops.append((value, 0))
        
        # Remove 'value' from stack
        # It is at pos_idx in src_idx
        del stacks[src_idx][pos_idx]
        
        # Update positions for boxes below 'value' in src_idx
        # Their indices decreased by 1
        for k in range(pos_idx):
            box_val = stacks[src_idx][k]
            pos[box_val] = (src_idx, k)
        
        # Mark value as removed (optional, but good for safety)
        # pos.pop(value, None)

    return ops

ops = solve()
for v, i in ops:
    print(v, i)
