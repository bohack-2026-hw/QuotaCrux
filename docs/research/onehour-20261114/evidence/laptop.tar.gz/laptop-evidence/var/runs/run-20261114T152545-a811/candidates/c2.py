import sys

def solve():
    it = iter(map(int, sys.stdin.buffer.read().split()))
    n, m = next(it), next(it)
    stacks = [[next(it) for _ in range(n // m)] for _ in range(m)]
    
    # Precompute position of each box for O(1) lookup
    pos = {}
    for i, stack in enumerate(stacks):
        for j, val in enumerate(stack):
            pos[val] = (i, j)
    
    ops = []
    for value in range(1, n + 1):
        src_idx, pos_idx = pos[value]
        if pos_idx + 1 < len(stacks[src_idx]):
            above = stacks[src_idx][pos_idx + 1:]
            # Choose destination stack to minimize future cost.
            # Heuristic: choose the stack with the smallest top element (if any),
            # or the shortest stack if all are empty.
            best_dest = -1
            best_score = float('inf')
            for j in range(m):
                if j == src_idx:
                    continue
                l = len(stacks[j])
                t = stacks[j][-1] if l > 0 else float('inf')
                score = (l, t)
                if score < best_score:
                    best_score = score
                    best_dest = j
            
            dest_idx = best_dest
            ops.append((above[0], dest_idx + 1))
            
            # Update state
            stacks[dest_idx].extend(above)
            del stacks[src_idx][pos_idx + 1:]
            
            # Update positions for moved boxes
            start_pos = len(stacks[dest_idx]) - len(above)
            for k, box_val in enumerate(above):
                pos[box_val] = (dest_idx, start_pos + k)
            
        ops.append((value, 0))
        
        # Remove 'value' from stack
        del stacks[src_idx][pos_idx]
        
        # Update positions for boxes below 'value' in src_idx
        for k in range(pos_idx):
            box_val = stacks[src_idx][k]
            pos[box_val] = (src_idx, k)
    
    return ops

ops = solve()
for v, i in ops:
    print(v, i)
