import sys, random

def main():
    data=list(map(int,sys.stdin.buffer.read().split()))
    if not data: return
    n,m=data[:2]
    initial=[data[2+i*(n//m):2+(i+1)*(n//m)] for i in range(m)]
    rng=random.Random(826)
    def simulate(tolerance,noise,baseline=False):
        stacks=[s[:] for s in initial]
        loc=[0]*(n+1)
        for i,s in enumerate(stacks):
            for x in s: loc[x]=i
        ops=[]; energy=0
        for v in range(1,n+1):
            src=loc[v]; s=stacks[src]; p=s.index(v)
            while len(s)>p+1:
                if baseline:
                    cut=p+1
                    dest=min((j for j in range(m) if j!=src),key=lambda j:len(stacks[j]))
                else:
                    cut=len(s)-1
                    mx=s[-1]
                    while cut>p+1 and s[cut-1]>=mx-tolerance:
                        cut-=1
                        if s[cut]>mx: mx=s[cut]
                    best=1e30; dest=-1
                    for j,t in enumerate(stacks):
                        if j==src: continue
                        low=min(t) if t else n+1
                        score=(low-mx if low>mx else 2*n+mx-low)
                        if noise: score+=rng.uniform(-noise,noise)
                        if score<best: best=score; dest=j
                block=s[cut:]
                energy+=len(block)+1
                ops.append((block[0],dest+1))
                stacks[dest].extend(block)
                for x in block: loc[x]=dest
                del s[cut:]
            s.pop(); ops.append((v,0))
        return energy,ops
    best,answer=simulate(0,0,True)
    for tol in [0,3,7,12,20,35,60,100,200]:
        for noise in [0,8,25,60]:
            score,ops=simulate(tol,noise)
            if score<best and len(ops)<=5000: best,answer=score,ops
    sys.stdout.write('\n'.join(str(v)+' '+str(i) for v,i in answer))
main()
