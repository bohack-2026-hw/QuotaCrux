import sys, random, time, math

def main():
    data=list(map(int,sys.stdin.buffer.read().split()))
    if not data: return
    started=time.perf_counter()
    n,m=data[:2]
    initial=[data[2+i*(n//m):2+(i+1)*(n//m)] for i in range(m)]
    rng=random.Random(826)
    def old_sim(tolerance,noise,baseline=False):
        stacks=[s[:] for s in initial]
        loc=[0]*(n+1)
        for i,s in enumerate(stacks):
            for x in s: loc[x]=i
        ops=[]; energy=0
        for v in range(1,n+1):
            src=loc[v]; s=stacks[src]; p=s.index(v)
            while len(s)>p+1:
                if baseline:
                    cut=p+1
                    dest=min((j for j in range(m) if j!=src),key=lambda j:len(stacks[j]))
                else:
                    cut=len(s)-1; mx=s[-1]
                    while cut>p+1 and s[cut-1]>=mx-tolerance:
                        cut-=1
                        if s[cut]>mx: mx=s[cut]
                    best=1e30; dest=-1
                    for j,t in enumerate(stacks):
                        if j==src: continue
                        low=min(t) if t else n+1
                        score=(low-mx if low>mx else 2*n+mx-low)
                        if noise: score+=rng.uniform(-noise,noise)
                        if score<best: best=score; dest=j
                block=s[cut:]; energy+=len(block)+1
                ops.append((block[0],dest+1)); stacks[dest].extend(block)
                for x in block: loc[x]=dest
                del s[cut:]
            s.pop(); ops.append((v,0))
        return energy,ops
    best,answer=old_sim(0,0,True)
    for tol in [0,3,7,12,20,35,60,100,200]:
        for noise in [0,8,25,60]:
            e,ops=old_sim(tol,noise)
            if e<best: best,answer=e,ops
    zero=[0.0]*m
    def simulate(params,record=False,limit=100000):
        stacks=[s[:] for s in initial]
        loc=[0]*(n+1)
        lows=[]
        for i,s in enumerate(stacks):
            lows.append(min(s) if s else n+1)
            for x in s: loc[x]=i
        ops=[]; energy=0; active=[]
        for v in range(1,n+1):
            src=loc[v]; s=stacks[src]; p=s.index(v)
            tol,bias=params[v]
            if len(s)>p+1: active.append(v)
            while len(s)>p+1:
                cut=len(s)-1; mx=s[-1]; mn=mx
                while cut>p+1 and s[cut-1]>=mx-tol:
                    cut-=1; x=s[cut]
                    if x>mx: mx=x
                    if x<mn: mn=x
                scorebest=1e30; dest=-1
                for j in range(m):
                    if j==src: continue
                    low=lows[j]
                    score=(low-mx if low>mx else 2*n+mx-low)+bias[j]
                    if score<scorebest: scorebest=score; dest=j
                block=s[cut:]; energy+=len(block)+1
                if energy>limit: return energy,None,active
                if record: ops.append((block[0],dest+1))
                stacks[dest].extend(block)
                if mn<lows[dest]: lows[dest]=mn
                for x in block: loc[x]=dest
                del s[cut:]
            s.pop(); lows[src]=min(s) if s else n+1
            if record: ops.append((v,0))
        return energy,ops,active
    local_best=100000; base=None; active=None
    for tol in [0,3,7,12,20,35,60]:
        for noise in [0,15,40]:
            params=[(tol,zero)]+[(tol,[rng.uniform(-noise,noise) for _ in range(m)] if noise else zero) for _ in range(n)]
            e,ops,act=simulate(params,True)
            if e<best: best,answer=e,ops
            if e<local_best: local_best=e; base=params; active=act
    current=base[:]; current_e=local_best
    champion=base[:]; champion_e=local_best
    deadline=started+1.72
    iterations=0
    while time.perf_counter()<deadline:
        iterations+=1
        progress=min(1.0,(time.perf_counter()-started)/1.72)
        temp=3.0*(1-progress)+0.2
        proposal=current[:]
        changes=1 if rng.random()<0.8 else rng.randrange(2,6)
        for _ in range(changes):
            v=rng.choice(active) if active and rng.random()<0.95 else rng.randint(1,n)
            oldtol,oldbias=proposal[v]
            tol=rng.choice([0,0,3,7,12,20,35,60,100,200]) if rng.random()<0.65 else oldtol
            if rng.random()<0.8:
                amp=rng.choice([0,5,15,30,60,120,240])
                bias=[rng.uniform(-amp,amp) for _ in range(m)] if amp else zero
            else: bias=oldbias
            proposal[v]=(tol,bias)
        e,_,act=simulate(proposal,False,current_e+30)
        if e<=current_e or (e-current_e<30 and rng.random()<math.exp((current_e-e)/temp)):
            current=proposal; current_e=e; active=act
            if e<champion_e:
                champion_e=e; champion=proposal[:]
                if e<best:
                    _,answer,_=simulate(proposal,True); best=e
        if iterations%180==0:
            current=champion[:]; current_e=champion_e
            _,_,active=simulate(current)
    sys.stdout.write('\n'.join(str(v)+' '+str(i) for v,i in answer))
main()
