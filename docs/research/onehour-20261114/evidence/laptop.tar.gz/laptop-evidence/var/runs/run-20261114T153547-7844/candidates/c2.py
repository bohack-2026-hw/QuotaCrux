import sys,time,random

def main():
    z=list(map(int,sys.stdin.buffer.read().split()))
    if not z:return
    n,m=z[:2]; initial=[z[2+i*(n//m):2+(i+1)*(n//m)] for i in range(m)]
    deadline=time.perf_counter()+1.72
    rng=random.Random(826);bestcost=10**9;bestops=[];trial=0
    while trial<400 and (trial==0 or time.perf_counter()<deadline):
        mode=0 if trial<5 else (trial%3!=0)
        if trial==0:a,b,g=0.7,3.0,0.12
        elif trial==1:a,b,g=1.8,4.0,0.1
        elif trial==2:a,b,g=0.25,2.0,0.08
        elif not mode:a,b,g=10**rng.uniform(-0.75,0.5),rng.uniform(1.3,5.0),rng.uniform(0.015,0.25)
        else:a,b,g=10**rng.uniform(-0.5,0.5),rng.uniform(1.0,4.5),rng.uniform(0.01,0.5)
        stacks=[s[:] for s in initial];where=[0]*(n+1)
        for i,s in enumerate(stacks):
            for x in s:where[x]=i
        mins=[min(s) if s else n+1 for s in stacks]
        ops=[];cost=0;aborted=False
        for v in range(1,n+1):
            src=where[v];s=stacks[src];pos=s.index(v)
            while len(s)>pos+1:
                h=len(s);bp=h-1;bd=0
                if not mode:
                    inv=0;mx=0;upper=[];ext=[0.0]*m;best=1e99
                    for p in range(h-1,pos,-1):
                        x=s[p];inv+=sum(y>x for y in upper);upper.append(x);mx=max(mx,x);length=h-p;base=1+a*inv
                        for d in range(m):
                            if d==src:continue
                            dm=mins[d]
                            if x>dm:ext[d]+=1+(x-dm)/n
                            val=(base+b*ext[d])/length+g*abs(dm-mx)/n
                            if val<best:best=val;bp=p;bd=d
                else:
                    lo=pos+1;L=h-lo;dp=[0.0]+[1e99]*L;prev=[0]*(L+1);dests=[0]*(L+1)
                    for q in range(1,L+1):
                        inv=0;bad=0;mx=0;mn=n+1;upper=[];ext=[0.0]*m
                        for p in range(q-1,-1,-1):
                            x=s[lo+p]
                            inv+=sum(y>x for y in upper)
                            upper.append(x);mx=max(mx,x);mn=min(mn,x)
                            bad=sum(y>mn for y in upper)
                            base=dp[p]+1+a*(0.8*bad+0.12*inv)
                            for d in range(m):
                                if d==src:continue
                                dm=mins[d]
                                if x>dm:ext[d]+=1+(x-dm)/n
                                val=base+b*ext[d]+g*abs(dm-mx)/n
                                if val<dp[q]:dp[q]=val;prev[q]=p;dests[q]=d
                    bp=lo+prev[L];bd=dests[L]
                chunk=s[bp:];ops.append((chunk[0],bd+1));cost+=len(chunk)+1
                stacks[bd].extend(chunk);mins[bd]=min(mins[bd],min(chunk))
                for x in chunk:where[x]=bd
                del s[bp:]
            ops.append((v,0));s.pop();mins[src]=min(s) if s else n+1
            if cost>=bestcost or (v%16==0 and trial>0 and time.perf_counter()>deadline):aborted=True;break
        if not aborted and cost<bestcost:bestcost=cost;bestops=ops
        trial+=1
    sys.stdout.write('\n'.join(f'{v} {d}' for v,d in bestops))
main()
