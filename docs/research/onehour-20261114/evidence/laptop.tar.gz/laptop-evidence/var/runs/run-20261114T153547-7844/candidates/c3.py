import sys,time,random

def main():
    z=list(map(int,sys.stdin.buffer.read().split()))
    if not z:return
    n,m=z[:2]; initial=[z[2+i*(n//m):2+(i+1)*(n//m)] for i in range(m)]
    deadline=time.perf_counter()+1.72
    rng=random.Random(826);bestcost=10**9;bestops=[];trial=0
    while trial<600 and (trial==0 or time.perf_counter()<deadline):
        mode=trial%4
        if trial==0:a,b,g=0.7,3.0,0.12;mode=0
        elif trial==1:a,b,g=1.8,4.0,0.1;mode=0
        elif trial==2:a,b,g=0.25,2.0,0.08;mode=0
        else:a,b,g=10**rng.uniform(-0.4,0.6),rng.uniform(0.9,4.0),rng.uniform(0.02,0.6)
        iv=rng.uniform(0.03,0.22) if mode else 0.12
        stacks=[s[:] for s in initial];where=[0]*(n+1)
        for i,s in enumerate(stacks):
            for x in s:where[x]=i
        mins=[min(s) if s else n+1 for s in stacks]
        ops=[];cost=0;aborted=False
        for v in range(1,n+1):
            src=where[v];s=stacks[src];pos=s.index(v)
            while len(s)>pos+1:
                h=len(s);lo=pos+1;L=h-lo
                dp=[0.0]+[1e99]*L;prev=[0]*(L+1);dests=[0]*(L+1)
                ds=[d for d in range(m) if d!=src]
                dm=[mins[d] for d in ds]
                for q in range(1,L+1):
                    inv=0;mx=0;mn=n+1;upper=[];records=[];ext=[0.0]*len(ds)
                    best=1e99;bp=0;bd=ds[0]
                    for p in range(q-1,-1,-1):
                        x=s[lo+p];inv+=sum(y>x for y in upper);upper.append(x)
                        if x>mx:mx=x
                        if x<mn:mn=x
                        records=[x]+[r for r in records if r<x]
                        bad=(len(upper)-1)*0.8 if mode==0 else len(upper)-len(records)
                        base=dp[p]+1+a*(bad+iv*inv)
                        for j,d in enumerate(ds):
                            t=dm[j]
                            if mode==2:
                                ex=sum(1+(r-t)/n for r in records if r>t)
                            else:
                                if x>t:ext[j]+=1+(x-t)/n
                                ex=ext[j]
                            val=base+b*ex+g*abs(t-mx)/n
                            if val<best:best=val;bp=p;bd=d
                    dp[q]=best;prev[q]=bp;dests[q]=bd
                bp=lo+prev[L];bd=dests[L]
                chunk=s[bp:];ops.append((chunk[0],bd+1));cost+=len(chunk)+1
                stacks[bd].extend(chunk);mins[bd]=min(mins[bd],min(chunk))
                for x in chunk:where[x]=bd
                del s[bp:]
            ops.append((v,0));s.pop();mins[src]=min(s) if s else n+1
            if cost>=bestcost or (v%16==0 and trial>0 and time.perf_counter()>deadline):aborted=True;break
        if not aborted and cost<bestcost:bestcost=cost;bestops=ops
        trial+=1
    sys.stdout.write('\n'.join(f'{v} {d}' for v,d in bestops))
main()
