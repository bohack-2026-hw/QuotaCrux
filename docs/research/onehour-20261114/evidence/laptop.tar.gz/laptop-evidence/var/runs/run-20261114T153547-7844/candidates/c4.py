import sys,time,random,bisect

def main():
    z=list(map(int,sys.stdin.buffer.read().split()))
    if not z:return
    n,m=z[:2];initial=[z[2+i*(n//m):2+(i+1)*(n//m)] for i in range(m)]
    deadline=time.perf_counter()+1.72
    rng=random.Random(826);bestcost=10**9;bestops=[];trial=0;bestpar=None
    br=bisect.bisect_right;ins=bisect.insort
    while trial<1000 and (trial==0 or time.perf_counter()<deadline):
        if trial==0:a,b,g,iv=1.4,2.5,0.3,0.12
        elif trial==1:a,b,g,iv=0.8,3.5,0.15,0.1
        elif trial%3==0 and bestpar:
            aa,bb,gg,ii=bestpar
            a=aa*rng.uniform(.7,1.4);b=bb*rng.uniform(.7,1.4);g=max(.01,gg*rng.uniform(.5,1.7));iv=ii*rng.uniform(.6,1.5)
        else:a,b,g,iv=10**rng.uniform(-.3,.6),rng.uniform(1,4),rng.uniform(.02,.8),rng.uniform(.015,.22)
        mode=trial%5
        stacks=[s[:] for s in initial];where=[0]*(n+1)
        for i,s in enumerate(stacks):
            for x in s:where[x]=i
        mins=[min(s) if s else n+1 for s in stacks];ops=[];cost=0;aborted=False
        for v in range(1,n+1):
            src=where[v];s=stacks[src];pos=s.index(v)
            while len(s)>pos+1:
                h=len(s);lo=pos+1;L=h-lo
                dp=[0.0]+[1e99]*L;prev=[0]*(L+1);dests=[0]*(L+1)
                ds=[d for d in range(m) if d!=src];dm=[mins[d] for d in ds]
                for q in range(1,L+1):
                    inv=0;mx=0;records=[];upper=[];ext=[0.0]*len(ds)
                    best=1e99;bp=0;bd=ds[0]
                    for p in range(q-1,-1,-1):
                        x=s[lo+p];inv+=len(upper)-br(upper,x);ins(upper,x)
                        if x>mx:mx=x
                        while records and records[-1]>x:records.pop()
                        records.append(x)
                        nr=len(records);length=q-p
                        base=dp[p]+1+a*(length-nr+iv*inv)
                        for j,d in enumerate(ds):
                            t=dm[j]
                            if mode==0:
                                if x>t:ext[j]+=1+(x-t)/n
                                ex=ext[j]
                            else:ex=nr-br(records,t)
                            val=base+b*ex+g*abs(t-mx)/n
                            if val<best:best=val;bp=p;bd=d
                    dp[q]=best;prev[q]=bp;dests[q]=bd
                bp=lo+prev[L];bd=dests[L];chunk=s[bp:]
                ops.append((chunk[0],bd+1));cost+=len(chunk)+1
                stacks[bd].extend(chunk);mins[bd]=min(mins[bd],min(chunk))
                for x in chunk:where[x]=bd
                del s[bp:]
            ops.append((v,0));s.pop();mins[src]=min(s) if s else n+1
            if cost>=bestcost or (v%16==0 and trial>0 and time.perf_counter()>deadline):aborted=True;break
        if not aborted and cost<bestcost:bestcost=cost;bestops=ops;bestpar=(a,b,g,iv)
        trial+=1
    sys.stdout.write('\n'.join(f'{v} {d}' for v,d in bestops))
main()
