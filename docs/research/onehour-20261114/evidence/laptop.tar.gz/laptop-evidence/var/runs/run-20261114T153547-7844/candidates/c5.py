import sys,time,random,bisect

def main():
    z=list(map(int,sys.stdin.buffer.read().split()))
    if not z:return
    n,m=z[:2];initial=[z[2+i*(n//m):2+(i+1)*(n//m)] for i in range(m)]
    start=time.perf_counter();deadline=start+1.74
    rng=random.Random(826);br=bisect.bisect_right;ins=bisect.insort
    zero=(0.0,)*m
    # Always keep a short, feasible fallback.
    st=[s[:] for s in initial];bestops=[];bestcost=0
    for v in range(1,n+1):
        src=next(i for i in range(m) if v in st[i]);p=st[src].index(v)
        if p+1<len(st[src]):
            d=min((i for i in range(m) if i!=src),key=lambda i:len(st[i]));ch=st[src][p+1:]
            bestops.append((ch[0],d+1));bestcost+=len(ch)+1;st[d].extend(ch);del st[src][p+1:]
        bestops.append((v,0));st[src].pop()
    bestpars=None
    def solve(pars,begin,prefix):
        stacks=[s[:] for s in initial];where=[0]*(n+1)
        for i,s in enumerate(stacks):
            for x in s:where[x]=i
        ops=[];cost=0
        for x,d in prefix:
            src=where[x]
            if d==0:stacks[src].pop()
            else:
                p=stacks[src].index(x);ch=stacks[src][p:];del stacks[src][p:];stacks[d-1].extend(ch);cost+=len(ch)+1
                for t in ch:where[t]=d-1
            ops.append((x,d))
        mins=[min(s) if s else n+1 for s in stacks]
        for v in range(begin,n+1):
            a,b,g,iv,mode,bias=pars[v]
            src=where[v];s=stacks[src];pos=s.index(v)
            while len(s)>pos+1:
                h=len(s);lo=pos+1;L=h-lo
                dp=[0.0]+[1e99]*L;prev=[0]*(L+1);dests=[0]*(L+1)
                ds=[d for d in range(m) if d!=src];dm=[mins[d] for d in ds]
                for q in range(1,L+1):
                    inv=0;mx=0;records=[];upper=[];ext=[0.0]*len(ds)
                    best=1e99;bp=0;bd=ds[0]
                    for p in range(q-1,-1,-1):
                        x=s[lo+p];inv+=len(upper)-br(upper,x);ins(upper,x)
                        if x>mx:mx=x
                        while records and records[-1]>x:records.pop()
                        records.append(x);nr=len(records);length=q-p
                        base=dp[p]+1+a*(length-nr+iv*inv)
                        for j,d in enumerate(ds):
                            t=dm[j]
                            if mode==0:
                                if x>t:ext[j]+=1+(x-t)/n
                                ex=ext[j]
                            else:ex=nr-br(records,t)
                            val=base+b*ex+g*abs(t-mx)/n+bias[d]
                            if val<best:best=val;bp=p;bd=d
                    dp[q]=best;prev[q]=bp;dests[q]=bd
                bp=lo+prev[L];bd=dests[L];chunk=s[bp:]
                ops.append((chunk[0],bd+1));cost+=len(chunk)+1
                if cost>=bestcost:return None
                stacks[bd].extend(chunk);mins[bd]=min(mins[bd],min(chunk))
                for x in chunk:where[x]=bd
                del s[bp:]
            ops.append((v,0));s.pop();mins[src]=min(s) if s else n+1
            if v%8==0 and time.perf_counter()>deadline:return None
        return cost,ops
    trial=0;bp_global=None
    while time.perf_counter()<start+.82 or bestpars is None:
        if trial==0:a,b,g,iv=1.4,2.5,.3,.12
        elif trial==1:a,b,g,iv=.8,3.5,.15,.1
        elif trial%3==0 and bp_global:
            aa,bb,gg,ii=bp_global;a=aa*rng.uniform(.7,1.4);b=bb*rng.uniform(.7,1.4);g=max(.01,gg*rng.uniform(.5,1.7));iv=ii*rng.uniform(.6,1.5)
        else:a,b,g,iv=10**rng.uniform(-.3,.6),rng.uniform(1,4),rng.uniform(.02,.8),rng.uniform(.015,.22)
        par=(a,b,g,iv,trial%5,zero);pars=[par]*(n+1)
        res=solve(pars,1,[])
        if res:
            bestcost,bestops=res;bestpars=pars;bp_global=(a,b,g,iv)
        trial+=1
        if time.perf_counter()>deadline:break
    if bestpars is not None:
        while time.perf_counter()<deadline:
            active=[];v=1
            for x,d in bestops:
                if d and (not active or active[-1]!=v):active.append(v)
                if not d:v=x+1
            if not active:break
            v=rng.choice(active);pars=bestpars[:]
            a,b,g,iv,mode,bias=pars[v]
            if rng.random()<.55:
                strength=rng.uniform(.3,2.0)
                bias=tuple(bias[d]+rng.uniform(-strength,strength) for d in range(m))
            else:
                a*=rng.uniform(.45,1.9);b*=rng.uniform(.45,1.9);g*=rng.uniform(.4,2.0);iv*=rng.uniform(.4,2)
                if rng.random()<.15:mode=0 if mode else 1
            pars[v]=(a,b,g,iv,mode,bias)
            prefix=[]
            for op in bestops:
                if op==(v-1,0):prefix.append(op);break
                if v==1:break
                prefix.append(op)
            res=solve(pars,v,prefix)
            if res:bestcost,bestops=res;bestpars=pars
    sys.stdout.write('\n'.join(f'{v} {d}' for v,d in bestops))
main()
