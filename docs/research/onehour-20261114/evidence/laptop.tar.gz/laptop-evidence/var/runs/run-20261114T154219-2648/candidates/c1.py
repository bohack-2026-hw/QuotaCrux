import sys
from collections import deque

def solve():
    data = list(map(int, sys.stdin.buffer.read().split()))
    n, m = data[0], data[1]
    stack_size = n // m
    stacks = []
    idx = 2
    for i in range(m):
        stacks.append(data[idx:idx+stack_size])
        idx += stack_size
    
    # Position map: box value -> (stack_index, position_in_stack)
    pos_map = {}
    for i, stack in enumerate(stacks):
        for j, val in enumerate(stack):
            pos_map[val] = (i, j)
    
    operations = []
    total_energy = 0
    
    def get_future_cost(dest_stack_idx, boxes_to_move):
        """Estimate the future cost of moving a group of boxes to dest_stack."""
        # Heuristic: prefer stacks where the moved boxes will be needed sooner
        # or where they won't block other boxes.
        # Simple heuristic: count how many of the moved boxes are 'small' (will be removed soon)
        # and penalize if they end up on top of larger boxes in the destination.
        cost = 0
        for box in boxes_to_move:
            # If the box is small, it's good to have it accessible.
            # But we don't know the exact future, so use a simple proxy.
            pass
        # For now, just return a constant to maintain baseline behavior,
        # but we can improve this later.
        return 0

    for value in range(1, n + 1):
        src_idx, src_pos = pos_map[value]
        src_stack = stacks[src_idx]
        
        if src_pos + 1 < len(src_stack):
            above_boxes = src_stack[src_pos + 1:]
            # Choose destination stack
            best_dest = -1
            best_score = float('inf')
            for j in range(m):
                if j == src_idx:
                    continue
                # Score: current length of destination stack + some heuristic
                score = len(stacks[j])
                # Add heuristic: prefer stacks with smaller boxes on top?
                # Or just keep it simple for now.
                if score < best_score:
                    best_score = score
                    best_dest = j
            
            if best_dest != -1:
                operations.append((above_boxes[0], best_dest + 1))
                total_energy += len(above_boxes) + 1
                
                # Update state
                moved = stacks[src_idx][src_pos + 1:]
                del stacks[src_idx][src_pos + 1:]
                stacks[best_dest].extend(moved)
                
                # Update pos_map
                for k, box in enumerate(moved):
                    pos_map[box] = (best_dest, len(stacks[best_dest]) - len(moved) + k)
        
        # Carry out box `value`
        operations.append((value, 0))
        
        # Update state: remove `value` from its stack
        src_idx, src_pos = pos_map[value]
        del stacks[src_idx][src_pos]
        # Update positions of all boxes above `value` in the same stack
        for k in range(src_pos, len(stacks[src_idx])):
            pos_map[stacks[src_idx][k]] = (src_idx, k)
        del pos_map[value]
    
    # Output
    out_lines = [f"{v} {i}" for v, i in operations]
    sys.stdout.write("\n".join(out_lines) + "\n")

solve()
