import sys

def solve():
    data = list(map(int, sys.stdin.buffer.read().split()))
    n, m = data[0], data[1]
    stack_size = n // m
    stacks = []
    idx = 2
    for i in range(m):
        stacks.append(data[idx:idx+stack_size])
        idx += stack_size
    
    # Position map: box value -> (stack_index, position_in_stack)
    pos_map = {}
    for i, stack in enumerate(stacks):
        for j, val in enumerate(stack):
            pos_map[val] = (i, j)
    
    operations = []
    total_energy = 0
    
    def simulate_future(stacks_copy, pos_map_copy, current_value, steps=3):
        """Simulate the next `steps` removals and return the energy cost."""
        energy = 0
        for v in range(current_value + 1, min(current_value + 1 + steps, n + 1)):
            if v not in pos_map_copy:
                continue
            src_idx, src_pos = pos_map_copy[v]
            src_stack = stacks_copy[src_idx]
            if src_pos + 1 < len(src_stack):
                above_boxes = src_stack[src_pos + 1:]
                # Choose destination stack (simple heuristic: shortest stack)
                best_dest = -1
                best_score = float('inf')
                for j in range(m):
                    if j == src_idx:
                        continue
                    score = len(stacks_copy[j])
                    if score < best_score:
                        best_score = score
                        best_dest = j
                
                if best_dest != -1:
                    k = len(above_boxes)
                    energy += k + 1
                    # Update state
                    moved = stacks_copy[src_idx][src_pos + 1:]
                    del stacks_copy[src_idx][src_pos + 1:]
                    stacks_copy[best_dest].extend(moved)
                    for k_box, box in enumerate(moved):
                        pos_map_copy[box] = (best_dest, len(stacks_copy[best_dest]) - len(moved) + k_box)
            
            # Carry out box `v`
            src_idx, src_pos = pos_map_copy[v]
            del stacks_copy[src_idx][src_pos]
            for k in range(src_pos, len(stacks_copy[src_idx])):
                pos_map_copy[stacks_copy[src_idx][k]] = (src_idx, k)
            del pos_map_copy[v]
        
        return energy

    for value in range(1, n + 1):
        src_idx, src_pos = pos_map[value]
        src_stack = stacks[src_idx]
        
        if src_pos + 1 < len(src_stack):
            above_boxes = src_stack[src_pos + 1:]
            # Choose destination stack using lookahead
            best_dest = -1
            best_total_cost = float('inf')
            for j in range(m):
                if j == src_idx:
                    continue
                
                # Simulate moving to stack j
                stacks_sim = [list(s) for s in stacks]
                pos_map_sim = dict(pos_map)
                
                # Perform the move in simulation
                moved = stacks_sim[src_idx][src_pos + 1:]
                del stacks_sim[src_idx][src_pos + 1:]
                stacks_sim[j].extend(moved)
                for k, box in enumerate(moved):
                    pos_map_sim[box] = (j, len(stacks_sim[j]) - len(moved) + k)
                
                # Remove current value
                src_idx_v, src_pos_v = pos_map_sim[value]
                del stacks_sim[src_idx_v][src_pos_v]
                for k in range(src_pos_v, len(stacks_sim[src_idx_v])):
                    pos_map_sim[stacks_sim[src_idx_v][k]] = (src_idx_v, k)
                del pos_map_sim[value]
                
                # Simulate future
                future_cost = simulate_future(stacks_sim, pos_map_sim, value, steps=3)
                total_cost = len(above_boxes) + 1 + future_cost
                
                if total_cost < best_total_cost:
                    best_total_cost = total_cost
                    best_dest = j
            
            if best_dest != -1:
                operations.append((above_boxes[0], best_dest + 1))
                total_energy += len(above_boxes) + 1
                
                # Update actual state
                moved = stacks[src_idx][src_pos + 1:]
                del stacks[src_idx][src_pos + 1:]
                stacks[best_dest].extend(moved)
                for k, box in enumerate(moved):
                    pos_map[box] = (best_dest, len(stacks[best_dest]) - len(moved) + k)
        
        # Carry out box `value`
        operations.append((value, 0))
        
        # Update state: remove `value` from its stack
        src_idx, src_pos = pos_map[value]
        del stacks[src_idx][src_pos]
        for k in range(src_pos, len(stacks[src_idx])):
            pos_map[stacks[src_idx][k]] = (src_idx, k)
        del pos_map[value]
    
    # Output
    out_lines = [f"{v} {i}" for v, i in operations]
    sys.stdout.write("\n".join(out_lines) + "\n")

solve()
